package com.omnifinder.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

open class BaseWidget(private val kind: WidgetKind) : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val v = kind.build(ctx); ids.forEach { mgr.updateAppWidget(it, v) }
    }
}
class SearchWidget : BaseWidget(WidgetKind.SEARCH)
class BarWidget : BaseWidget(WidgetKind.BAR)
class ToolsWidget : BaseWidget(WidgetKind.TOOLS)
