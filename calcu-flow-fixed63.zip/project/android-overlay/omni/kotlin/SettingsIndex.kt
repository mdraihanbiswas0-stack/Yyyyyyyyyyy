package com.omnifinder.app

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** ফোনের সেটিংস অপশন সার্চ: বাংলা + ইংরেজি কীওয়ার্ড, ক্লিক করলে সরাসরি ওই পেজ খোলে। */
class SettingItem(val label: String, val keywords: String, val action: String)

object SettingsIndex {
    private val items = listOf(
        SettingItem("ওয়াই-ফাই", "wifi wi-fi wireless network ইন্টারনেট নেটওয়ার্ক পাসওয়ার্ড", Settings.ACTION_WIFI_SETTINGS),
        SettingItem("ব্লুটুথ", "bluetooth ব্লুটুথ পেয়ার ডিভাইস", Settings.ACTION_BLUETOOTH_SETTINGS),
        SettingItem("মোবাইল ডাটা ও নেটওয়ার্ক", "mobile data network sim সিম ডাটা রোমিং apn", Settings.ACTION_NETWORK_OPERATOR_SETTINGS),
        SettingItem("ডাটা রোমিং", "roaming রোমিং", Settings.ACTION_DATA_ROAMING_SETTINGS),
        SettingItem("বিমান মোড", "airplane flight mode ফ্লাইট বিমান", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
        SettingItem("হটস্পট ও টেদারিং", "hotspot tethering টেদারিং হটস্পট শেয়ার ইন্টারনেট", "android.settings.TETHER_SETTINGS"),
        SettingItem("ওয়্যারলেস ও নেটওয়ার্ক", "wireless networks ওয়্যারলেস", Settings.ACTION_WIRELESS_SETTINGS),
        SettingItem("VPN", "vpn ভিপিএন", Settings.ACTION_VPN_SETTINGS),
        SettingItem("NFC", "nfc এনএফসি ট্যাপ পেমেন্ট", Settings.ACTION_NFC_SETTINGS),
        SettingItem("ডিসপ্লে ও ব্রাইটনেস", "display brightness ব্রাইটনেস উজ্জ্বলতা স্ক্রিন টাইমআউট font size ফন্ট লেখা বড় dark mode ডার্ক মোড theme", Settings.ACTION_DISPLAY_SETTINGS),
        SettingItem("নাইট লাইট", "night light চোখের আরাম blue light নাইট", Settings.ACTION_NIGHT_DISPLAY_SETTINGS),
        SettingItem("শব্দ ও ভলিউম", "sound volume ভলিউম রিংটোন ringtone নোটিফিকেশন শব্দ vibration ভাইব্রেশন", Settings.ACTION_SOUND_SETTINGS),
        SettingItem("বিরক্ত করবেন না (DND)", "do not disturb dnd silent সাইলেন্ট zen", "android.settings.ZEN_MODE_SETTINGS"),
        SettingItem("ব্যাটারি সেভার", "battery saver ব্যাটারি চার্জ power", Settings.ACTION_BATTERY_SAVER_SETTINGS),
        SettingItem("স্টোরেজ", "storage স্টোরেজ জায়গা space memory মেমোরি", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        SettingItem("মেমোরি কার্ড", "sd card memory card এসডি কার্ড", Settings.ACTION_MEMORY_CARD_SETTINGS),
        SettingItem("অ্যাপস", "apps application অ্যাপ ইনস্টল uninstall আনইনস্টল", Settings.ACTION_APPLICATION_SETTINGS),
        SettingItem("ডিফল্ট অ্যাপস", "default apps ডিফল্ট ব্রাউজার", Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
        SettingItem("অ্যাপ ব্যবহারের তথ্য", "usage access screen time স্ক্রিন টাইম ব্যবহার", Settings.ACTION_USAGE_ACCESS_SETTINGS),
        SettingItem("লোকেশন", "location gps লোকেশন অবস্থান", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
        SettingItem("নিরাপত্তা ও স্ক্রিন লক", "security lock পিন pin password পাসওয়ার্ড fingerprint ফিঙ্গারপ্রিন্ট face সিকিউরিটি", Settings.ACTION_SECURITY_SETTINGS),
        SettingItem("গোপনীয়তা", "privacy প্রাইভেসি পারমিশন permission", Settings.ACTION_PRIVACY_SETTINGS),
        SettingItem("অ্যাক্সেসিবিলিটি", "accessibility talkback অ্যাক্সেসিবিলিটি", Settings.ACTION_ACCESSIBILITY_SETTINGS),
        SettingItem("ভাষা ও অঞ্চল", "language locale ভাষা বাংলা ইংরেজি region", Settings.ACTION_LOCALE_SETTINGS),
        SettingItem("কীবোর্ড", "keyboard কীবোর্ড input method টাইপিং", Settings.ACTION_INPUT_METHOD_SETTINGS),
        SettingItem("তারিখ ও সময়", "date time তারিখ সময় timezone টাইমজোন clock", Settings.ACTION_DATE_SETTINGS),
        SettingItem("অ্যাকাউন্ট ও সিঙ্ক", "account sync অ্যাকাউন্ট গুগল সিঙ্ক", Settings.ACTION_SYNC_SETTINGS),
        SettingItem("অ্যাকাউন্ট যোগ করুন", "add account নতুন অ্যাকাউন্ট", Settings.ACTION_ADD_ACCOUNT),
        SettingItem("ফোন সম্পর্কে", "about phone device info imei মডেল ফোন সম্পর্কে android version ভার্সন", Settings.ACTION_DEVICE_INFO_SETTINGS),
        SettingItem("ডেভেলপার অপশন", "developer options ডেভেলপার usb debugging", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
        SettingItem("নোটিফিকেশন অ্যাক্সেস", "notification access listener নোটিফিকেশন", Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),
        SettingItem("কাস্ট / স্ক্রিন শেয়ার", "cast screen mirror কাস্ট tv টিভি", Settings.ACTION_CAST_SETTINGS),
        SettingItem("ওয়ালপেপার", "wallpaper ওয়ালপেপার ব্যাকগ্রাউন্ড", Intent.ACTION_SET_WALLPAPER),
        SettingItem("স্ক্রিন সেভার", "screen saver dream স্ক্রিনসেভার", "android.settings.DREAM_SETTINGS"),
        SettingItem("প্রিন্টিং", "print প্রিন্ট প্রিন্টার", "android.settings.ACTION_PRINT_SETTINGS"),
        SettingItem("WebView", "webview ওয়েবভিউ chromium", Settings.ACTION_WEBVIEW_SETTINGS),
        SettingItem("হার্ড কীবোর্ড", "hard keyboard physical keyboard", Settings.ACTION_HARD_KEYBOARD_SETTINGS),
        SettingItem("সব সেটিংস", "settings সেটিংস", Settings.ACTION_SETTINGS),
    )

    private fun norm(s: String) = s.lowercase()

    fun search(q: String): List<Result> {
        val k = norm(q)
        return items.filter { norm(it.label).contains(k) || norm(it.keywords).contains(k) }.take(12).map { i ->
            Result(i.label, "সেটিংস অপশন", Source.SETTING) { c: Context ->
                runCatching { c.startActivity(Intent(i.action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    .onFailure { runCatching { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            }
        }
    }

    /** খালি সার্চে "সেটিংস" টুল চাপলে সব অপশন */
    fun all(): List<Result> = items.map { i ->
        Result(i.label, "সেটিংস অপশন", Source.SETTING) { c: Context ->
            runCatching { c.startActivity(Intent(i.action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure { runCatching { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
        }
    }
}
