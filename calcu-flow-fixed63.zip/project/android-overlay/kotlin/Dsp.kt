package com.earflow.app

import kotlin.math.abs
import kotlin.math.tanh

// কল অডিও প্রসেসর: হাই-পাস ফিল্টার + স্মার্ট অটো-গেইন (RMS) + সফট-লিমিটার
class Dsp(private val rate: Int, private val maxGain: Float) {
    private var px = 0f
    private var py = 0f
    private var gain = 1f
    private var tmp = FloatArray(4096)
    var peak = 0
        private set

    // ~100Hz এর নিচের গুনগুন/কাঁপুনি কাটে
    private val a: Float = run {
        val rc = 1f / (2f * Math.PI.toFloat() * 100f)
        rc / (rc + 1f / rate)
    }

    private fun limit(v: Float): Float {
        val x = v / 32768f
        val ax = abs(x)
        val y = if (ax <= 0.8f) ax else 0.8f + 0.2f * tanh((ax - 0.8f) / 0.2f)
        return (if (x < 0) -y else y) * 32767f
    }

    // buf (n স্যাম্পল) -> out (16-bit little-endian), রিটার্ন = বাইট সংখ্যা
    fun process(buf: ShortArray, n: Int, out: ByteArray): Int {
        if (tmp.size < n) tmp = FloatArray(n)
        var sum = 0.0
        for (i in 0 until n) {
            val ax = abs(buf[i].toInt())
            if (ax > peak) peak = ax
            val x = buf[i].toFloat()
            val y = a * (py + x - px)
            px = x; py = y
            tmp[i] = y
            sum += (y * y).toDouble()
        }
        val rms = Math.sqrt(sum / n).toFloat()
        val g0 = gain
        if (rms > 60f) {
            val want = (3500f / rms).coerceIn(1f, maxGain)
            // জোরে হলে সঙ্গে সঙ্গে কমে, আস্তে হলে ধীরে ধীরে বাড়ে
            gain = if (want < gain) want else gain + (want - gain) * 0.08f
        } else {
            gain = maxOf(1f, gain * 0.99f)
        }
        val g1 = gain
        for (i in 0 until n) {
            val g = g0 + (g1 - g0) * i / n
            val s = limit(tmp[i] * g).toInt().coerceIn(-32768, 32767)
            out[2 * i] = (s and 0xff).toByte()
            out[2 * i + 1] = ((s shr 8) and 0xff).toByte()
        }
        return n * 2
    }
}
