package __APP_ID__;

/** "cal" প্যাডের উইজেট */
public class WidgetCal extends PadWidgetBase {
    @Override
    protected String pad() {
        return "cal";
    }
}
