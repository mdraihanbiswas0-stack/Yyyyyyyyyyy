package com.omnifinder.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class Result(val title: String, val subtitle: String, val source: Source, val open: (Context) -> Unit)

object SearchEngine {

    /** প্রতিটি উৎসের ফলাফল তৈরি হওয়া মাত্র ধাপে ধাপে পাঠায়। */
    fun search(ctx: Context, q: String, has: (String) -> Boolean): Flow<Pair<Source, List<Result>>> = channelFlow {
        if (q.isBlank()) return@channelFlow
        val P = android.Manifest.permission
        fun guarded(perm: String?, src: Source, f: () -> List<Result>) = async(Dispatchers.IO) {
            if (perm == null || has(perm)) runCatching { f() }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { send(src to it) }
            Unit
        }
        val jobs = listOf(
            guarded(null, Source.APP) { apps(ctx, q) },
            guarded(null, Source.SETTING) { SettingsIndex.search(q) },
            guarded(P.READ_CONTACTS, Source.CONTACT) { DeviceData.contacts(ctx, q) },
            guarded(P.READ_CALL_LOG, Source.CALL) { DeviceData.calls(ctx, q) },
            guarded(P.READ_SMS, Source.SMS) { DeviceData.sms(ctx, q) },
            guarded(P.READ_CALENDAR, Source.EVENT) { DeviceData.calendar(ctx, q) },
            async(Dispatchers.IO) { runCatching { media(ctx, q) }.getOrDefault(emptyList()).forEach { (s, l) -> send(s to l) } },
            guarded(null, Source.BOOKMARK) { DeviceData.browser(ctx, q) },
            guarded(null, Source.CONTENT) { DeviceData.fileContents(ctx, q) },
            async(Dispatchers.IO) { runCatching { quran(q).takeIf { it.isNotEmpty() }?.let { send(Source.QURAN to it) } } },
            async(Dispatchers.IO) { runCatching { wiki(q).takeIf { it.isNotEmpty() }?.let { send(Source.WIKI to it) } } },
            async(Dispatchers.IO) { online(q).groupBy { it.source }.forEach { (s, l) -> send(s to l) } },
        )
        jobs.awaitAll()
    }

    private fun view(c: Context, uri: Uri, mime: String? = null) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            if (mime != null) setDataAndType(uri, mime) else data = uri
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { c.startActivity(i) }.onFailure { android.widget.Toast.makeText(c, "এটি খোলার মতো অ্যাপ পাওয়া যায়নি", android.widget.Toast.LENGTH_SHORT).show() }
    }

    fun url(c: Context, u: String) {
        when {
            u.startsWith("http") -> runCatching {
                c.startActivity(Intent(c, BrowserActivity::class.java).putExtra("url", u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            u.startsWith("geo:") -> {
                // ম্যাপ অ্যাপ না থাকলে ব্রাউজারে গুগল ম্যাপ
                val ok = runCatching { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
                if (!ok) url(c, "https://www.google.com/maps/search/?api=1&query=" + u.substringAfter("q=", ""))
            }
            else -> view(c, Uri.parse(u))
        }
    }

    /** "অ্যাপস" টুল চাপলে সব ইনস্টল করা অ্যাপ (নাম অনুযায়ী) */
    private fun allApps(ctx: Context): List<Result> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.loadLabel(pm).toString() to it }
            .sortedBy { it.first.lowercase() }
            .distinctBy { it.second.activityInfo.packageName }
            .map { (label, ri) ->
                Result(label, ri.activityInfo.packageName, Source.APP) { c ->
                    pm.getLaunchIntentForPackage(ri.activityInfo.packageName)?.let { c.startActivity(it) }
                }
            }
    }

    /** খালি সার্চ বক্সে স্থানীয় টুল চাপলে সেই টুলের সাম্প্রতিক/সব তালিকা দেখায়। */
    fun browse(ctx: Context, t: Tool): List<Pair<Source, List<Result>>> {
        val out: List<Pair<Source, List<Result>>> = when (t) {
            Tool.APPS -> listOf(Source.APP to allApps(ctx))
            Tool.SETTINGS -> listOf(Source.SETTING to SettingsIndex.all())
            Tool.CONTACTS -> listOf(Source.CONTACT to DeviceData.allContacts(ctx))
            Tool.CALLS -> listOf(Source.CALL to DeviceData.recentCalls(ctx))
            Tool.MESSAGES -> listOf(Source.SMS to DeviceData.recentSms(ctx))
            Tool.CALENDAR -> listOf(Source.EVENT to DeviceData.upcomingEvents(ctx))
            Tool.PHOTOS -> listOf(Source.PHOTO to DeviceData.recentMedia(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Source.PHOTO))
            Tool.VIDEOS -> listOf(Source.VIDEO to DeviceData.recentMedia(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Source.VIDEO))
            Tool.AUDIO -> listOf(Source.AUDIO to DeviceData.recentMedia(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Source.AUDIO))
            Tool.FILES -> listOf(Source.FILE to DeviceData.recentFiles(ctx))
            else -> emptyList()
        }
        return out.filter { it.second.isNotEmpty() }
    }

    /** টুল → সরাসরি ওয়েবসাইট/ম্যাপ (সার্চ লেখা থাকলে সেই সার্চে) */
    fun openOnline(ctx: Context, t: Tool, q: String) {
        val e = enc(q.trim()); val blank = q.isBlank()
        val u = when (t) {
            Tool.YOUTUBE -> if (blank) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=$e"
            Tool.FACEBOOK -> if (blank) "https://www.facebook.com" else "https://www.facebook.com/search/top?q=$e"
            Tool.TIKTOK -> if (blank) "https://www.tiktok.com" else "https://www.tiktok.com/search?q=$e"
            Tool.WEB -> if (blank) "https://www.google.com" else "https://www.google.com/search?q=$e"
            Tool.WIKI -> if (blank) "https://bn.wikipedia.org" else "https://bn.wikipedia.org/w/index.php?search=$e"
            Tool.QURAN -> if (blank) "https://quran.com" else "https://quran.com/search?q=$e"
            Tool.MAPS -> if (blank) "geo:0,0" else "geo:0,0?q=$e"
            else -> return
        }
        url(ctx, u)
    }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun apps(ctx: Context, q: String): List<Result> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .filter { it.loadLabel(pm).toString().contains(q, true) || it.activityInfo.packageName.contains(q, true) }
            .take(15).map { ri ->
                Result(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, Source.APP) { c ->
                    pm.getLaunchIntentForPackage(ri.activityInfo.packageName)?.let { c.startActivity(it) }
                }
            }
    }

    private fun media(ctx: Context, q: String): List<Pair<Source, List<Result>>> {
        val uri = MediaStore.Files.getContentUri("external")
        val cols = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.Files.FileColumns.SIZE)
        val map = linkedMapOf(Source.PHOTO to mutableListOf<Result>(), Source.VIDEO to mutableListOf(),
            Source.AUDIO to mutableListOf(), Source.FILE to mutableListOf())
        runCatching {
            ctx.contentResolver.query(uri, cols, (if (android.os.Build.VERSION.SDK_INT >= 29) "${cols[1]} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?" else "${cols[1]} LIKE ?"),
                if (android.os.Build.VERSION.SDK_INT >= 29) arrayOf("%$q%", "%$q%") else arrayOf("%$q%"),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val src = when (c.getInt(3)) {
                        MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE -> Source.PHOTO
                        MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO -> Source.VIDEO
                        MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO -> Source.AUDIO
                        else -> Source.FILE
                    }
                    val list = map[src]!!; if (list.size >= 20) continue
                    val id = ContentUris.withAppendedId(uri, c.getLong(0)); val mime = c.getString(2)
                    list += Result(c.getString(1) ?: "", "${c.getLong(4) / 1024} KB", src) { cx -> view(cx, id, mime) }
                }
            }
        }
        return map.filter { it.value.isNotEmpty() }.map { it.key to it.value }
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun quran(q: String): List<Result> {
        val j = JSONObject(get("https://api.alquran.cloud/v1/search/${enc(q)}/all/bn.bengali"))
        val m = j.optJSONObject("data")?.optJSONArray("matches") ?: JSONArray()
        return (0 until minOf(m.length(), 10)).map { i ->
            val o = m.getJSONObject(i); val s = o.getJSONObject("surah")
            val ref = "${s.getInt("number")}:${o.getInt("numberInSurah")}"
            Result("${s.getString("englishName")} — আয়াত $ref", o.getString("text"), Source.QURAN) { c ->
                url(c, "https://quran.com/$ref") }
        }
    }

    private fun wiki(q: String): List<Result> {
        val a = JSONArray(get("https://bn.wikipedia.org/w/api.php?action=opensearch&limit=5&format=json&search=${enc(q)}"))
        val t = a.getJSONArray(1); val d = a.getJSONArray(2); val u = a.getJSONArray(3)
        return (0 until t.length()).map { i -> Result(t.getString(i), d.optString(i), Source.WIKI) { c -> url(c, u.getString(i)) } }
    }

    /** ইউটিউব/ফেসবুক/টিকটক/ক্রোমের নিজস্ব ডাটা পড়া যায় না — সার্চ পেজ খুলে দেওয়া হয়। */
    fun online(q: String): List<Result> = listOf(
        Result("ওয়েবে খুঁজুন: $q", "ব্রাউজারে সার্চ", Source.WEB) { c -> url(c, "https://www.google.com/search?q=${enc(q)}") },
        Result("ইউটিউবে খুঁজুন: $q", "youtube.com", Source.YOUTUBE) { c -> url(c, "https://www.youtube.com/results?search_query=${enc(q)}") },
        Result("ফেসবুকে খুঁজুন: $q", "facebook.com", Source.FACEBOOK) { c -> url(c, "https://www.facebook.com/search/top?q=${enc(q)}") },
        Result("টিকটকে খুঁজুন: $q", "tiktok.com", Source.TIKTOK) { c -> url(c, "https://www.tiktok.com/search?q=${enc(q)}") },
        Result("ম্যাপে খুঁজুন: $q", "ম্যাপ", Source.MAPS) { c -> url(c, "geo:0,0?q=${enc(q)}") },
    )
}
