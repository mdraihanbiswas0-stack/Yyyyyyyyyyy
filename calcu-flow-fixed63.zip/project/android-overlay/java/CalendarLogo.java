package __APP_ID__;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Calendar;

/**
 * ক্যালেন্ডার-লোগো: চকচকে নীল গোল বেসের ওপর সাদা ক্যালেন্ডার-পাতা — লাল মাথায় আজকের বার (বাংলায়),
 * মাঝে বড় তারিখ (বাংলা সংখ্যায়), নিচে ইংরেজি মাসের বাংলা নাম। অ্যাপের ভেতরের ক্যালেন্ডার-ট্যাবের লোগোর সাথে একই নকশা।
 */
public final class CalendarLogo {
    private CalendarLogo() {}

    private static final String[] WD = {"রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"};
    private static final String[] MN = {"জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"};

    /** 24 → ২৪ */
    private static String bn(int n) {
        String s = String.valueOf(n);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            b.append(c >= '0' && c <= '9' ? (char) ('\u09E6' + (c - '0')) : c);
        }
        return b.toString();
    }

    /** লেখা maxW-এর চেয়ে চওড়া হলে ছোট করে মাপে আনা */
    private static void fit(Paint t, String text, float size, float maxW) {
        t.setTextSize(size);
        float w = t.measureText(text);
        if (w > maxW && w > 0) t.setTextSize(size * maxW / w);
    }

    public static Bitmap draw(int s, Calendar cal) {
        Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        float k = s / 512f;
        float mid = s / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        String weekday = WD[Math.max(0, Math.min(6, cal.get(Calendar.DAY_OF_WEEK) - 1))];
        String day = bn(cal.get(Calendar.DAY_OF_MONTH));
        String mon = MN[Math.max(0, Math.min(11, cal.get(Calendar.MONTH)))];

        // ১) গোল বেস (রঙের গ্রেডিয়েন্ট)
        p.setShader(new RadialGradient(0.32f * s, 0.24f * s, 0.95f * s,
                new int[]{0xFF7DD3FC, 0xFF2F8CF0, 0xFF1B2FA0}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(mid, mid, 250 * k, p);
        p.setShader(null);

        // ২) ক্যালেন্ডার-পাতা (ছায়াসহ)
        RectF page = new RectF(108 * k, 118 * k, 404 * k, 414 * k);
        Paint sh = new Paint(Paint.ANTI_ALIAS_FLAG);
        sh.setColor(0xFFFFFFFF);
        sh.setShadowLayer(18 * k, 0, 10 * k, 0x66000000);
        c.drawRoundRect(page, 44 * k, 44 * k, sh);
        p.setShader(new LinearGradient(0, 118 * k, 0, 414 * k, 0xFFFFFFFF, 0xFFE5ECF6, Shader.TileMode.CLAMP));
        c.drawRoundRect(page, 44 * k, 44 * k, p);
        p.setShader(null);

        // ৩) লাল মাথা (পাতার গোল কোণে আটকানো)
        c.save();
        Path clip = new Path();
        clip.addRoundRect(page, 44 * k, 44 * k, Path.Direction.CW);
        c.clipPath(clip);
        p.setShader(new LinearGradient(0, 118 * k, 0, 210 * k, 0xFFFF6B6B, 0xFFDC2640, Shader.TileMode.CLAMP));
        c.drawRect(108 * k, 118 * k, 404 * k, 210 * k, p);
        p.setShader(null);
        p.setColor(0x59B91C1C);
        c.drawRect(108 * k, 206 * k, 404 * k, 212 * k, p);
        c.restore();

        // ৪) বাঁধার রিং
        p.setColor(0xFF334155);
        c.drawRoundRect(new RectF(170 * k, 92 * k, 196 * k, 146 * k), 13 * k, 13 * k, p);
        c.drawRoundRect(new RectF(316 * k, 92 * k, 342 * k, 146 * k), 13 * k, 13 * k, p);
        p.setColor(0x8CFFFFFF);
        c.drawRoundRect(new RectF(176 * k, 98 * k, 184 * k, 128 * k), 4 * k, 4 * k, p);
        c.drawRoundRect(new RectF(322 * k, 98 * k, 330 * k, 128 * k), 4 * k, 4 * k, p);

        // ৫) লেখা: বার (বাংলায়), তারিখ (বাংলা সংখ্যা), মাস (বাংলা নাম)
        Typeface bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTypeface(bold);
        t.setTextAlign(Paint.Align.CENTER);

        t.setColor(0xFFFFFFFF);
        fit(t, weekday, 46 * k, 236 * k);
        c.drawText(weekday, mid, 186 * k, t);

        t.setColor(0xFF1E293B);
        t.setTextSize((day.length() > 1 ? 190 : 210) * k);
        c.drawText(day, mid, 350 * k, t);

        t.setColor(0xFFDC2640);
        fit(t, mon, 40 * k, 236 * k);
        c.drawText(mon, mid, 400 * k, t);

        // ৬) চকচকে গ্লস + রিম + ঝিলিক
        c.save();
        Path circ = new Path();
        circ.addCircle(mid, mid, 246 * k, Path.Direction.CW);
        c.clipPath(circ);
        p.setShader(new LinearGradient(0, 8 * k, 0, 216 * k, 0x8EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawOval(new RectF(56 * k, 8 * k, 456 * k, 216 * k), p);
        p.setShader(null);
        c.restore();

        Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(9 * k);
        rim.setShader(new LinearGradient(0, 6 * k, 0, 506 * k,
                new int[]{0xF2FFFFFF, 0x14FFFFFF, 0x66000000}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(mid, mid, 246 * k, rim);

        p.setColor(0xD9FFFFFF);
        c.drawCircle(150 * k, 96 * k, 9 * k, p);
        p.setColor(0xB3FFFFFF);
        c.drawCircle(176 * k, 74 * k, 4.5f * k, p);
        return bm;
    }
}
