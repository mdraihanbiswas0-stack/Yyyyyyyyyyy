#!/usr/bin/env node
/**
 * `npx cap add android` এর পরে চলে। জেনারেট-হওয়া Android প্রজেক্টে বসায়:
 *  - সব দরকারি পারমিশন + queries (TTS / ভয়েস) + অটোফিল সার্ভিস + হোম-স্ক্রিন উইজেট
 *  - নেটিভ জাভা কোড (প্লাগইন, অটোফিল), আইকন, নোটিফিকেশন-আইকন
 *  - সাইনিং কনফিগ, ভার্সন, targetSdk, lint সেটিং
 * বারবার চালালেও নিরাপদ (idempotent)।
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const ANDROID = path.join(ROOT, "android");
const OVERLAY = path.join(ROOT, "android-overlay");

const log = (...a) => console.log("[patch]", ...a);
const die = (m) => {
  console.error("[patch] ত্রুটি:", m);
  process.exit(1);
};

if (!fs.existsSync(ANDROID)) die("android ফোল্ডার নেই — আগে `npx cap add android` চালান");

const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, "capacitor.config.json"), "utf8"));
const APP_ID = cfg.appId;
const APP_NAME = cfg.appName;
const VERSION_CODE = parseInt(process.env.VERSION_CODE || "1", 10) || 1;
const VERSION_NAME = process.env.VERSION_NAME || `1.0.${VERSION_CODE}`;
const TARGET_SDK = process.env.TARGET_SDK || "34";

const read = (p) => fs.readFileSync(p, "utf8");
const write = (p, s) => fs.writeFileSync(p, s);

function walk(dir, out = []) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, f.name);
    if (f.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

/* ---------- ১) জাভা কোড ---------- */
const javaDir = path.join(ANDROID, "app/src/main/java", ...APP_ID.split("."));
fs.mkdirSync(javaDir, { recursive: true });
// পুরনো/ডিফল্ট MainActivity সরিয়ে আমাদেরটা
for (const f of walk(path.join(ANDROID, "app/src/main/java"))) {
  if (path.basename(f) === "MainActivity.java" || path.basename(f) === "MainActivity.kt") fs.unlinkSync(f);
}
for (const f of fs.readdirSync(path.join(OVERLAY, "java"))) {
  const src = read(path.join(OVERLAY, "java", f)).replaceAll("__APP_ID__", APP_ID);
  write(path.join(javaDir, f), src);
}
log("জাভা ফাইল বসেছে →", path.relative(ROOT, javaDir));
// ইয়ার-ফ্লো (অডিও ও স্ক্রিন রেকর্ডার) — Kotlin সোর্স, প্যাকেজ com.earflow.app
const ktSrc = path.join(OVERLAY, "kotlin");
if (fs.existsSync(ktSrc)) {
  const ktDir = path.join(ANDROID, "app/src/main/java/com/earflow/app");
  fs.mkdirSync(ktDir, { recursive: true });
  for (const f of fs.readdirSync(ktSrc)) fs.copyFileSync(path.join(ktSrc, f), path.join(ktDir, f));
  log("Kotlin (ইয়ার-ফ্লো) ফাইল বসেছে →", path.relative(ROOT, ktDir));
}

// ওমনি-ফাইন্ডার (সার্চ + ব্রাউজার) — Kotlin + Compose সোর্স, প্যাকেজ com.omnifinder.app
const omniSrc = path.join(OVERLAY, "omni/kotlin");
if (fs.existsSync(omniSrc)) {
  const omDir = path.join(ANDROID, "app/src/main/java/com/omnifinder/app");
  fs.mkdirSync(omDir, { recursive: true });
  for (const f of fs.readdirSync(omniSrc)) write(path.join(omDir, f), read(path.join(omniSrc, f)).replaceAll("__APP_ID__", APP_ID));
  log("Kotlin (ওমনি-ফাইন্ডার) ফাইল বসেছে →", path.relative(ROOT, omDir));
}

/* ---------- ২) রিসোর্স (আইকন, লেআউট, নোটিফিকেশন-আইকন) ---------- */
const resDir = path.join(ANDROID, "app/src/main/res");
for (const f of walk(path.join(OVERLAY, "res"))) {
  const rel = path.relative(path.join(OVERLAY, "res"), f);
  const dest = path.join(resDir, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(f, dest);
}
// ডিফল্ট Capacitor-স্প্ল্যাশ ছবি মুছে ফেলা — তার জায়গায় কালো পর্দার মাঝখানে আপনার লোগো (drawable/splash.xml)
try {
  for (const f of walk(resDir)) {
    if (path.basename(f) === "splash.png") fs.unlinkSync(f);
  }
} catch (e) {
  log("স্প্ল্যাশ বদলানো গেল না (সমস্যা নেই):", e.message);
}
// অ্যাপের নাম (বাংলা) — strings.xml
const stringsPath = path.join(resDir, "values/strings.xml");
if (fs.existsSync(stringsPath)) {
  let s = read(stringsPath);
  const esc = APP_NAME.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/'/g, "\\'");
  s = s.replace(/(<string name="app_name">)[^<]*(<\/string>)/, `$1${esc}$2`);
  s = s.replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, `$1${esc}$2`);
  write(stringsPath, s);
}
// Android 12+ এর সিস্টেম স্প্ল্যাশ: কালো ব্যাকগ্রাউন্ড + লোগো
const stylesPath0 = path.join(resDir, "values/styles.xml");
if (fs.existsSync(stylesPath0)) {
  let st = read(stylesPath0);
  if (!st.includes("jn_splash")) {
    st = st.replace(
      /(<style name="AppTheme\.NoActionBarLaunch"[^>]*SplashScreen[^>]*>)/,
      `$1\n        <!-- jn_splash -->\n        <item name="windowSplashScreenBackground">#000000</item>\n        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>`
    );
    write(stylesPath0, st);
  }
}
// স্ট্যাটাস/নেভিগেশন বার কালো
const stylesPath = path.join(resDir, "values/styles.xml");
if (fs.existsSync(stylesPath)) {
  let s = read(stylesPath);
  if (!s.includes("jn_bars")) {
    s = s.replace(
      /(<style name="AppTheme\.NoActionBar"[^>]*>)/,
      `$1\n        <!-- jn_bars -->\n        <item name="android:statusBarColor">#000000</item>\n        <item name="android:navigationBarColor">#000000</item>\n        <item name="android:windowBackground">#000000</item>`
    );
    write(stylesPath, s);
  }
}

/* ---------- ৩) AndroidManifest ---------- */
const manPath = path.join(ANDROID, "app/src/main/AndroidManifest.xml");
let man = read(manPath);

const PERMS = [
  ["android.permission.INTERNET"],
  ["android.permission.ACCESS_NETWORK_STATE"],
  ["android.permission.POST_NOTIFICATIONS"], // নোটিফিকেশন (Android 13+)
  ["android.permission.VIBRATE"],
  ["android.permission.WAKE_LOCK"],
  ["android.permission.RECEIVE_BOOT_COMPLETED"], // রিবুটের পর রিমাইন্ডার ফিরিয়ে আনা
  ["android.permission.SCHEDULE_EXACT_ALARM"], // ঠিক সময়ে রিমাইন্ডার
  ["android.permission.USE_EXACT_ALARM"],
  ["android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"], // ব্যাকগ্রাউন্ডে রিমাইন্ডার না থামা
  ["android.permission.RECORD_AUDIO"], // ভয়েস টাইপিং / "ফ্লো" ভয়েস সহকারী
  ["android.permission.MODIFY_AUDIO_SETTINGS"],
  ["android.permission.USE_BIOMETRIC"], // ফিঙ্গারপ্রিন্ট/ফেস (কী-ফ্লো)
  ["android.permission.USE_FINGERPRINT"],
  ["android.permission.WRITE_EXTERNAL_STORAGE", 'android:maxSdkVersion="28"'],
  // ইয়ার-ফ্লো (কল/স্ক্রিন রেকর্ডার)
  ["android.permission.READ_PHONE_STATE"],
  ["android.permission.READ_CALL_LOG"],
  ["android.permission.PROCESS_OUTGOING_CALLS"],
  ["android.permission.READ_CONTACTS"],
  ["android.permission.FOREGROUND_SERVICE"],
  ["android.permission.FOREGROUND_SERVICE_MICROPHONE"],
  ["android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"],
  ["android.permission.SYSTEM_ALERT_WINDOW"],
  // ওমনি-ফাইন্ডার (ফোনের ভেতরে সার্চ)
  ["android.permission.READ_SMS"],
  ["android.permission.READ_CALENDAR"],
  ["android.permission.READ_MEDIA_IMAGES"],
  ["android.permission.READ_MEDIA_VIDEO"],
  ["android.permission.READ_MEDIA_AUDIO"],
  ["android.permission.READ_EXTERNAL_STORAGE", 'android:maxSdkVersion="32"'],
  ["android.permission.MANAGE_EXTERNAL_STORAGE"],
];
let permXml = "";
for (const [name, extra] of PERMS) {
  if (!man.includes(`"${name}"`)) {
    permXml += `    <uses-permission android:name="${name}"${extra ? " " + extra : ""} />\n`;
  }
}
if (!man.includes("android.hardware.microphone")) {
  permXml += `    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n`;
  permXml += `    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n`;
}
if (!man.includes("<queries>")) {
  permXml += `    <queries>
        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>
        <intent><action android:name="android.speech.RecognitionService" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:mimeType="text/calendar" /></intent>
        <intent><action android:name="android.intent.action.SEND" /><data android:mimeType="*/*" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="https" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="tel" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="mailto" /></intent>
        <intent><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent>
        <intent><action android:name="android.speech.action.RECOGNIZE_SPEECH" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="geo" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="sms" /></intent>
    </queries>\n`;
}
if (permXml) man = man.replace(/<application/, permXml + "    <application");

// <application> বৈশিষ্ট্য
function setAttr(tagRe, attr, val) {
  man = man.replace(tagRe, (tag) => {
    const re = new RegExp(`\\s${attr.replace(":", "\\:")}="[^"]*"`);
    if (re.test(tag)) return tag.replace(re, ` ${attr}="${val}"`);
    return tag.replace(/>$/, `\n        ${attr}="${val}">`);
  });
}
setAttr(/<application[^>]*>/, "android:allowBackup", "false");
setAttr(/<application[^>]*>/, "android:hardwareAccelerated", "true");
setAttr(/<application[^>]*>/, "android:usesCleartextTraffic", "false");
setAttr(/<application[^>]*>/, "android:largeHeap", "true");
// MainActivity: কিবোর্ড, পোর্ট্রেট
setAttr(/<activity[^>]*android:name="[^"]*MainActivity"[^>]*>/, "android:windowSoftInputMode", "adjustResize");
setAttr(/<activity[^>]*android:name="[^"]*MainActivity"[^>]*>/, "android:screenOrientation", "portrait");

if (!man.includes("JonakiAutofillService")) {
  const comps = `
        <!-- কী-ফ্লো অটোফিল সার্ভিস (Settings → Autofill service থেকে বাছাই করতে হয়) -->
        <service
            android:name=".JonakiAutofillService"
            android:exported="true"
            android:label="কী-ফ্লো অটোফিল"
            android:permission="android.permission.BIND_AUTOFILL_SERVICE">
            <intent-filter>
                <action android:name="android.service.autofill.AutofillService" />
            </intent-filter>
        </service>
        <activity
            android:name=".AutofillAuthActivity"
            android:excludeFromRecents="true"
            android:exported="false"
            android:theme="@android:style/Theme.Translucent.NoTitleBar" />
`;
  man = man.replace(/<\/application>/, comps + "    </application>");
}
if (!man.includes("com.earflow.app.EarActivity")) {
  const ear = `
        <!-- ইয়ার-ফ্লো: অডিও (কল) ও স্ক্রিন রেকর্ডার প্যাড -->
        <activity
            android:name="com.earflow.app.EarActivity"
            android:exported="false"
            android:label="ইয়ার-ফ্লো"
            android:theme="@style/Theme.AppCompat.Light.NoActionBar" />
        <activity
            android:name="com.earflow.app.EditorActivity"
            android:exported="false"
            android:theme="@style/Theme.AppCompat.Light.NoActionBar" />
        <provider
            android:name="com.earflow.app.EarFileProvider"
            android:authorities="com.earflow.app.fp"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/ef_file_paths" />
        </provider>
        <receiver android:name="com.earflow.app.CallReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.PHONE_STATE" />
                <action android:name="android.intent.action.NEW_OUTGOING_CALL" />
            </intent-filter>
        </receiver>
        <service
            android:name="com.earflow.app.CallRecordService"
            android:exported="false"
            android:foregroundServiceType="microphone" />
        <service
            android:name="com.earflow.app.ScreenRecordService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection|microphone" />
        <service
            android:name="com.earflow.app.EarFlowAccessibilityService"
            android:exported="true"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_config" />
        </service>
`;
  man = man.replace(/<\/application>/, ear + "    </application>");
}
if (!man.includes("com.omnifinder.app.OmniActivity")) {
  const omni = `
        <!-- ওমনি-ফাইন্ডার: সার্চ + ব্রাউজার প্যাড -->
        <activity
            android:name="com.omnifinder.app.OmniActivity"
            android:exported="false"
            android:label="ওমনি-ফাইন্ডার"
            android:launchMode="singleTop"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/of_Theme" />
        <activity
            android:name="com.omnifinder.app.BrowserActivity"
            android:exported="false"
            android:label="ওমনি-ব্রাউজার"
            android:configChanges="orientation|screenSize|keyboardHidden|smallestScreenSize|screenLayout"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/of_Theme" />
        <receiver android:name="com.omnifinder.app.SearchWidget" android:exported="true" android:label="@string/of_wd_search">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/of_widget_info" />
        </receiver>
        <receiver android:name="com.omnifinder.app.BarWidget" android:exported="true" android:label="@string/of_wd_bar">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/of_widget_bar_info" />
        </receiver>
        <receiver android:name="com.omnifinder.app.ToolsWidget" android:exported="true" android:label="@string/of_wd_tools">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/of_widget_tools_info" />
        </receiver>
`;
  man = man.replace(/<\/application>/, omni + "    </application>");
}
// হোম-স্ক্রিন উইজেট: ৯টি প্যাডের জন্য ৮টি + একটি লম্বা (সব প্যাডের লোগো); ক্যালেন্ডার ও লম্বা উইজেট তারিখ বদলালে নিজে আপডেট হয়
if (!man.includes(".WidgetEar")) {
  if (man.includes(".WidgetPk")) man = man.replace(/\n\s*<!-- হোম-স্ক্রিন উইজেট -->[\s\S]*?(?=<\/application>)/, "\n");
  const DATE_FILTER = `
            <intent-filter>
                <action android:name="android.intent.action.DATE_CHANGED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>`;
  const rcv = (cls, label, xml, dyn) => `
        <receiver
            android:name=".${cls}"
            android:exported="true"
            android:label="@string/${label}">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>${dyn ? DATE_FILTER : ""}
            <meta-data
                android:name="android.appwidget.provider"
                android:resource="@xml/${xml}" />
        </receiver>`;
  let w = "\n        <!-- হোম-স্ক্রিন উইজেট -->";
  for (const k of ["pk", "calc", "biz", "nt", "med", "kf", "cal", "jf", "ear", "omni"]) {
    w += rcv("Widget" + k[0].toUpperCase() + k.slice(1), "wd_" + k, "widget_pad_" + k, k === "cal");
  }
  w += rcv("WidgetBar", "wd_bar", "widget_bar", true);
  w += "\n";
  man = man.replace(/<\/application>/, w + "    </application>");
}
/* ---------- ৩.২) ভবিষ্যতের নতুন প্যাড ও মডিউল (নিজে নিজে জোড়া লাগে) ---------- */
const moduleDeps = [];
{
  // (ক) autowire-pads.mjs যে নতুন প্যাডগুলো পেয়েছে: উইজেট-রিসিভার, PadWidgets ও লম্বা-উইজেটে যোগ
  const apPath = path.join(OVERLAY, ".autopads.json");
  if (fs.existsSync(apPath)) {
    const ids = JSON.parse(read(apPath)).pads || [];
    const cap = (x) => x[0].toUpperCase() + x.slice(1);
    for (const id of ids) {
      if (!man.includes(`.Widget${cap(id)}"`)) {
        const rec = `
        <receiver android:name=".Widget${cap(id)}" android:exported="true" android:label="@string/wd_${id}">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_pad_${id}" />
        </receiver>
`;
        man = man.replace(/<\/application>/, rec + "    </application>");
      }
    }
    const pwPath = path.join(javaDir, "PadWidgets.java");
    const wbPath = path.join(javaDir, "WidgetBar.java");
    if (ids.length && fs.existsSync(pwPath)) {
      let pw = read(pwPath);
      for (const id of ids) {
        if (!pw.includes(`"${id}"`)) {
          pw = pw.replace('"ear", "omni"};', `"ear", "omni", "${id}"};`);
          pw = pw.replace('        if ("omni".equals(kind)) return WidgetOmni.class;', `        if ("omni".equals(kind)) return WidgetOmni.class;\n        if ("${id}".equals(kind)) return Widget${cap(id)}.class;`);
        }
      }
      write(pwPath, pw);
    }
    if (ids.length && fs.existsSync(wbPath)) {
      let wb = read(wbPath);
      const barLay = path.join(resDir, "layout/widget_bar.xml");
      let lay = fs.existsSync(barLay) ? read(barLay) : "";
      let n = 10;
      for (const id of ids) {
        if (!wb.includes(`R.id.wb_${n}`)) {
          wb = wb.replace(/R\.id\.wb_9(?!\d)/, `R.id.wb_9, R.id.wb_${n}`);
          lay = lay.replace(/<\/LinearLayout>\s*$/, `    <ImageView android:id="@+id/wb_${n}" android:layout_width="0dp" android:layout_height="match_parent" android:layout_weight="1" android:contentDescription="@string/wd_app" android:padding="2dp" android:scaleType="fitCenter" />\n</LinearLayout>\n`);
        }
        n++;
      }
      write(wbPath, wb);
      if (lay) write(barLay, lay);
    }
    log("নতুন প্যাডের উইজেট জোড়া লেগেছে:", ids.join(", "));
  }
  // (খ) android-overlay/modules/<নাম>/ — নতুন নেটিভ ফিচার-মডিউল (কোড, রিসোর্স, ম্যানিফেস্ট, অনুমতি, ডিপেন্ডেন্সি)
  const modRoot = path.join(OVERLAY, "modules");
  if (fs.existsSync(modRoot)) {
    const copyTree = (src, dst, tx) => {
      for (const e of fs.readdirSync(src, { withFileTypes: true })) {
        const a = path.join(src, e.name), b = path.join(dst, e.name);
        if (e.isDirectory()) { fs.mkdirSync(b, { recursive: true }); copyTree(a, b, tx); }
        else fs.writeFileSync(b, tx ? Buffer.from(tx(fs.readFileSync(a, "utf8"))) : fs.readFileSync(a));
      }
    };
    const ktRoot = path.join(ANDROID, "app/src/main/java");
    for (const m of fs.readdirSync(modRoot, { withFileTypes: true }).filter((d) => d.isDirectory())) {
      const md = path.join(modRoot, m.name);
      const ktDir = path.join(md, "kotlin");
      for (const dirName of ["kotlin", "java"]) {
        const d = path.join(md, dirName);
        if (!fs.existsSync(d)) continue;
        const walk = (dir) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
          const f = path.join(dir, e.name);
          if (e.isDirectory()) { walk(f); continue; }
          if (!/\.(kt|java)$/.test(e.name)) continue;
          const src = read(f).replaceAll("__APP_ID__", APP_ID);
          const pk = (src.match(/^\s*package\s+([\w.]+)/m) || [])[1];
          const out = pk ? path.join(ktRoot, ...pk.split(".")) : javaDir;
          fs.mkdirSync(out, { recursive: true });
          write(path.join(out, e.name), src);
        } };
        walk(d);
      }
      if (fs.existsSync(path.join(md, "res"))) copyTree(path.join(md, "res"), resDir, (t) => t.replaceAll("__APP_ID__", APP_ID));
      const mf = path.join(md, "manifest-application.xml");
      if (fs.existsSync(mf)) man = man.replace(/<\/application>/, read(mf).replaceAll("__APP_ID__", APP_ID) + "\n    </application>");
      const pf = path.join(md, "permissions.txt");
      if (fs.existsSync(pf)) for (const l of read(pf).split("\n").map((x) => x.trim()).filter((x) => x && !x.startsWith("#"))) {
        const nm = l.includes(".") ? l : "android.permission." + l;
        if (!man.includes(`"${nm}"`)) man = man.replace(/<application/, `<uses-permission android:name="${nm}" />\n    <application`);
      }
      const qf = path.join(md, "queries.xml");
      if (fs.existsSync(qf) && man.includes("</queries>")) man = man.replace("</queries>", read(qf) + "\n    </queries>");
      const df = path.join(md, "gradle-deps.txt");
      if (fs.existsSync(df)) for (const l of read(df).split("\n").map((x) => x.trim()).filter((x) => x && !x.startsWith("#"))) moduleDeps.push(l);
      log("মডিউল জোড়া লেগেছে:", m.name);
    }
  }
}
write(manPath, man);
log("AndroidManifest প্যাচ হয়েছে");

/* ---------- ৩.৫) Kotlin (ইয়ার-ফ্লো-র জন্য) ---------- */
{
  const rootG = path.join(ANDROID, "build.gradle");
  let rg = read(rootG);
  if (!rg.includes("kotlin-gradle-plugin")) {
    rg = rg.replace(/(classpath\s+['"]com\.android\.tools\.build:gradle:[^'"]+['"])/, `$1\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.25'`);
    write(rootG, rg);
    log("Kotlin gradle প্লাগইন যোগ হয়েছে");
  }
}

/* ---------- ৪) variables.gradle (targetSdk) ---------- */
const varPath = path.join(ANDROID, "variables.gradle");
if (fs.existsSync(varPath)) {
  let v = read(varPath);
  v = v.replace(/targetSdkVersion\s*=\s*\d+/, `targetSdkVersion = ${TARGET_SDK}`);
  write(varPath, v);
  log("targetSdk =", TARGET_SDK);
}

/* ---------- ৫) app/build.gradle (সাইনিং, ভার্সন, lint) ---------- */
const gPath = path.join(ANDROID, "app/build.gradle");
let g = read(gPath);
g = g.replace(/versionCode\s+\d+/, `versionCode ${VERSION_CODE}`);
g = g.replace(/versionName\s+"[^"]*"/, `versionName "${VERSION_NAME}"`);
if (!g.includes("jonaki-signing")) {
  g = g.replace(
    /android\s*\{/,
    `android {
    // jonaki-signing
    signingConfigs {
        jonakiRelease {
            storeFile file(System.getenv("JN_KEYSTORE") ?: "\${rootDir}/../keystore/jonaki-release.jks")
            storePassword System.getenv("JN_STORE_PASS") ?: "jonaki-release"
            keyAlias System.getenv("JN_KEY_ALIAS") ?: "jonaki"
            keyPassword System.getenv("JN_KEY_PASS") ?: "jonaki-release"
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }`
  );
  g = g.replace(/buildTypes\s*\{\s*release\s*\{/, (m) => `${m}\n            signingConfig signingConfigs.jonakiRelease`);
}
if (!g.includes("kotlin-android")) {
  g = g.replace(/apply plugin:\s*['"]com\.android\.application['"]/, `apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'`);
  g = g.replace(/dependencies\s*\{/, `dependencies {\n    implementation "androidx.core:core-ktx:1.15.0"`);
  g = g.replace(/android\s*\{/, `android {\n    kotlinOptions { jvmTarget = "21" }`);
}
if (!g.includes("compose-bom")) {
  // ওমনি-ফাইন্ডার (Jetpack Compose + ML Kit + WebView)
  g = g.replace(/android\s*\{/, `android {\n    buildFeatures { compose true }\n    composeOptions { kotlinCompilerExtensionVersion "1.5.15" }`);
  g = g.replace(/dependencies\s*\{/, `dependencies {
    implementation platform("androidx.compose:compose-bom:2024.06.00")
    implementation "androidx.activity:activity-compose:1.9.1"
    implementation "androidx.compose.ui:ui"
    implementation "androidx.compose.material3:material3"
    implementation "androidx.compose.material:material-icons-extended"
    implementation "androidx.webkit:webkit:1.11.0"
    implementation "androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4"
    implementation "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1"
    implementation "com.google.android.gms:play-services-code-scanner:16.1.0"
    implementation "com.google.mlkit:image-labeling:17.0.9"`);
}
if (moduleDeps.length) {
  g = g.replace(/dependencies\s*\{/, `dependencies {\n${moduleDeps.map((d) => "    implementation " + (d.startsWith("platform(") ? d : JSON.stringify(d))).join("\n")}`);
}
write(gPath, g);
log(`build.gradle প্যাচ হয়েছে (versionCode=${VERSION_CODE})`);

/* ---------- ৬) gradle.properties ---------- */
const gpPath = path.join(ANDROID, "gradle.properties");
if (fs.existsSync(gpPath)) {
  let p = read(gpPath);
  if (!/org\.gradle\.jvmargs/.test(p)) p += "\norg.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8\n";
  else p = p.replace(/org\.gradle\.jvmargs=.*/, "org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8");
  if (!/android\.useAndroidX/.test(p)) p += "android.useAndroidX=true\n";
  write(gpPath, p);
}

log(`সব প্যাচ শেষ ✔ (appId=${APP_ID})`);
