package com.earflow.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

// কলের সময় কিছু ফোনে মাইক্রোফোন অ্যাক্সেস পেতে এই সার্ভিস চালু থাকা দরকার
class EarFlowAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
