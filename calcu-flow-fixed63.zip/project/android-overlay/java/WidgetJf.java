package __APP_ID__;

/** "jf" প্যাডের উইজেট */
public class WidgetJf extends PadWidgetBase {
    @Override
    protected String pad() {
        return "jf";
    }
}
