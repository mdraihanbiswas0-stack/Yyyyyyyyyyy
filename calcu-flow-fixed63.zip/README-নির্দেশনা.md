# ক্যালকু-ফ্লো — জিপ + ওয়ার্কফ্লো নির্দেশনা

## ব্যবহার (৩ ধাপ)
1. `build-apk.yml` ফাইলটি রিপোজিটরিতে **`.github/workflows/build-apk.yml`** নামে রাখুন (আগের workflow ফাইল থাকলে মুছে এটি রাখুন)।
2. এই **জিপ ফাইলটি** (যেটার ভেতরে এই README আছে) রিপোজিটরির মূল ফোল্ডারে আপলোড/commit করুন — **আনজিপ করবেন না**।
3. GitHub নিজেই জিপ খুলে সব ফাইল সাজাবে, আইকন-উইজেট-অনুমতি বসাবে, যাচাই করবে ও APK বানাবে।
   APK: **Actions → রান → Artifacts** অথবা **Releases** পেজে।
   (ম্যানুয়ালি চালাতে: Actions → "ক্যালকু-ফ্লো APK বিল্ড" → Run workflow)

## জিপের গঠন
```
ZIP-INFO.json        ← mode: full (সম্পূর্ণ প্রজেক্ট) বা patch (শুধু বদলানো ফাইল)
README-নির্দেশনা.md   ← এই ফাইল
build-apk.yml        ← workflow (উপরের ধাপ ১)
project/             ← সম্পূর্ণ প্রজেক্ট
  www/index.html     ← পুরো অ্যাপের ওয়েব-অংশ (সব প্যাড, UI, ফিচার)
  android-overlay/   ← নেটিভ অংশ: java/ (প্লাগইন, অটোফিল, উইজেট), kotlin/ (ইয়ার-ফ্লো), omni/kotlin/ (ওমনি-ফাইন্ডার), res/
  scripts/           ← patch-android.mjs (অনুমতি/উইজেট/মডিউল বসায়), autowire-pads.mjs, inventory.mjs, verify-build.mjs …
  resources/ keystore/ package.json capacitor.config.json
```

## নতুন আপডেট এলে
- নতুন **সম্পূর্ণ** জিপ আপলোড করলে workflow সেটিকেই প্রজেক্ট ধরে (পুরোনো ফিচারও তাতে থাকে)। একাধিক জিপ থাকলে পুরোনো→নতুন ক্রমে পড়ে।
- নতুন **আংশিক** জিপ (`ZIP-INFO.json`-এ `"mode": "patch"`) আগের প্রজেক্টের ওপর বসে। বাদ দিতে জিপে `.remove-files` (প্রতি লাইনে একটি পথ)।
- প্রতি বিল্ডে `features.json` বানানো হয় এবং আগের রিলিজের সাথে মিলিয়ে **নতুন/বাদ যাওয়া** প্যাড, টুল, অনুমতি, ফিচার Job Summary-তে দেখায়।

## নতুন প্যাড যোগ করার নিয়ম (workflow বাকিটা নিজে করে)
1. `www/index.html`-এর `PADS` তালিকায় লাইন যোগ: `["নতুন_id","tbN","নাম"]` এবং ট্যাব-বাটন `<button class="tb" id="tbN" …>`।
2. (ঐচ্ছিক) `android-overlay/res/drawable-nodpi/pad_<id>.png` লোগো — না দিলে workflow নিজে একটি বানায়।
3. workflow নিজে বানায়: উইজেট ক্লাস `Widget<Id>.java`, উইজেট XML, উইজেটের নাম, ম্যানিফেস্ট-রিসিভার, লম্বা-উইজেটে যোগ।
   → ফলে প্রতিটি প্যাডের নিজস্ব হোম-স্ক্রিন উইজেট থাকে এবং অ্যাপের সেটিংস → উইজেট থেকেও বসানো যায়।

## নতুন নেটিভ ফিচার-মডিউল (Kotlin/Java)
`project/android-overlay/modules/<নাম>/` ফোল্ডারে দিন (সবই ঐচ্ছিক):
`kotlin/`, `java/` (প্যাকেজ-অনুযায়ী নিজে বসে; `__APP_ID__` ব্যবহার করা যায়), `res/`, `manifest-application.xml`,
`permissions.txt`, `queries.xml`, `gradle-deps.txt` (প্রতি লাইনে একটি `group:artifact:version`).

## অনুমতি
সব অনুমতি `patch-android.mjs`-এর তালিকা অনুযায়ী ম্যানিফেস্টে বসে। অ্যাপে **সেটিংস → অনুমতি কেন্দ্র** থেকে নোটিফিকেশন, মাইক, কন্টাক্ট, কল লগ, এসএমএস, ক্যালেন্ডার, মিডিয়া, সব-ফাইল, ওভারলে, ব্যাটারি, ঠিক-সময়ের অ্যালার্ম এক জায়গা থেকে দেওয়া যায়।

## সাইনিং
Repository Secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (ঐচ্ছিক)। না দিলে `project/keystore/jonaki-release.jks` ব্যবহার হয়।

## সমস্যা হলে
Actions-এ লাল ❌ ধাপের লেখা কপি করে পাঠান। প্রথম ধাপ ("জিপ খোঁজা…")-এর Job Summary-তে কোন জিপ পেল ও কী করল তা লেখা থাকে।
