package com.omnifinder.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.core.graphics.PathParser
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** নিজস্ব আঁকা আইকন-সেট (ইমোজি নয়) — প্রতিটি আইকন ২৪×২৪ গ্রিডে হাতে ডিজাইন করা। */
enum class Glyph {
    CAMERA, GALLERY, QR, MIC, APPS, CONTACT, FOLDER, IMAGE, VIDEO, MUSIC, BOOK, GLOBE, PLAY, PEOPLE, SHORTS,
    WEB, PIN, GEAR, CHAT, PHONE, CALENDAR, WIDGETS, COMPASS, TORCH, BOOKMARK, DOC, HISTORY, INCOGNITO, SEARCH
}

private class Layer(val d: String, val alpha: Float = 1f, val stroke: Float = 0f)

object ToolIcons {
    private fun n(v: Float) = v.toString()
    private fun rr(x: Float, y: Float, w: Float, h: Float, r: Float) =
        "M${n(x + r)},${n(y)} H${n(x + w - r)} A${n(r)},${n(r)} 0 0 1 ${n(x + w)},${n(y + r)} V${n(y + h - r)} " +
        "A${n(r)},${n(r)} 0 0 1 ${n(x + w - r)},${n(y + h)} H${n(x + r)} A${n(r)},${n(r)} 0 0 1 ${n(x)},${n(y + h - r)} " +
        "V${n(y + r)} A${n(r)},${n(r)} 0 0 1 ${n(x + r)},${n(y)} Z "
    private fun ci(cx: Float, cy: Float, r: Float) =
        "M${n(cx - r)},${n(cy)} A${n(r)},${n(r)} 0 1 0 ${n(cx + r)},${n(cy)} A${n(r)},${n(r)} 0 1 0 ${n(cx - r)},${n(cy)} Z "

    private fun gear(): String {
        val sb = StringBuilder(); val teeth = 8; val ro = 10.2f; val ri = 7.4f
        fun pt(a: Double, r: Float) = "${n((12 + r * cos(a)).toFloat())},${n((12 + r * sin(a)).toFloat())}"
        for (i in 0 until teeth) {
            val a0 = 2 * PI * i / teeth
            val step = 2 * PI / teeth
            sb.append(if (i == 0) "M" else "L").append(pt(a0 - 0.30, ri)).append(" L").append(pt(a0 - 0.17, ro))
                .append(" L").append(pt(a0 + 0.17, ro)).append(" L").append(pt(a0 + 0.30, ri))
            val next = a0 + step - 0.30
            sb.append(" A${n(ri)},${n(ri)} 0 0 1 ").append(pt(next, ri)).append(" ")
        }
        sb.append("Z ").append(ci(12f, 12f, 3.3f))
        return sb.toString()
    }

    private val defs: Map<Glyph, List<Layer>> by lazy {
        mapOf(
            Glyph.CAMERA to listOf(
                Layer(rr(8f, 3.8f, 8f, 4.5f, 1.6f), 0.6f),
                Layer(rr(2.5f, 6.5f, 19f, 14f, 3.2f) + ci(12f, 13.5f, 4.6f)),
                Layer(ci(12f, 13.5f, 2.6f), 0.75f)
            ),
            Glyph.GALLERY to listOf(
                Layer(rr(6f, 3f, 15.5f, 13f, 2.6f), 0.55f),
                Layer(rr(2.5f, 7.5f, 16f, 13.5f, 2.6f) + ci(7.6f, 12f, 1.7f) + "M4.5,18.6 L9.6,13.8 L12.6,16.6 L14.6,14.8 L16.8,18.6 Z")
            ),
            Glyph.QR to listOf(
                Layer(rr(3f, 3f, 7.5f, 7.5f, 1.8f) + rr(5f, 5f, 3.5f, 3.5f, 0.6f)),
                Layer(rr(13.5f, 3f, 7.5f, 7.5f, 1.8f) + rr(15.5f, 5f, 3.5f, 3.5f, 0.6f)),
                Layer(rr(3f, 13.5f, 7.5f, 7.5f, 1.8f) + rr(5f, 15.5f, 3.5f, 3.5f, 0.6f)),
                Layer(rr(6f, 6f, 1.5f, 1.5f, 0.4f) + rr(16.5f, 6f, 1.5f, 1.5f, 0.4f) + rr(6f, 16.5f, 1.5f, 1.5f, 0.4f)),
                Layer(rr(13.5f, 13.5f, 3.2f, 3.2f, 0.8f) + rr(18f, 13.5f, 3f, 3f, 0.8f) + rr(13.5f, 18f, 3f, 3f, 0.8f) + rr(18f, 18f, 3f, 3f, 0.8f), 0.85f)
            ),
            Glyph.MIC to listOf(
                Layer(rr(8.5f, 2.5f, 7f, 12.5f, 3.5f)),
                Layer("M5.5,11 A6.5,6.5 0 0 0 18.5,11", 1f, 2f),
                Layer("M12,17.5 V21 M8.5,21 H15.5", 1f, 2f)
            ),
            Glyph.APPS to listOf(
                Layer(rr(3f, 3f, 7.5f, 7.5f, 2.2f)),
                Layer(rr(13.5f, 3f, 7.5f, 7.5f, 2.2f), 0.6f),
                Layer(rr(3f, 13.5f, 7.5f, 7.5f, 2.2f), 0.6f),
                Layer(ci(17.25f, 17.25f, 4f))
            ),
            Glyph.CONTACT to listOf(
                Layer(rr(2.5f, 4f, 19f, 16f, 3.2f) + ci(9f, 10.3f, 2.3f) +
                    "M4.8,17.6 C5.2,14.9 7,13.9 9,13.9 C11,13.9 12.8,14.9 13.2,17.6 Z " +
                    rr(15f, 9.2f, 4f, 1.6f, 0.8f) + rr(15f, 12.6f, 4f, 1.6f, 0.8f))
            ),
            Glyph.FOLDER to listOf(
                Layer("M3,7.5 A2.5,2.5 0 0 1 5.5,5 H9.2 C9.9,5 10.5,5.3 10.9,5.8 L12,7 H18.5 A2.5,2.5 0 0 1 21,9.5 V17.5 A2.5,2.5 0 0 1 18.5,20 H5.5 A2.5,2.5 0 0 1 3,17.5 Z", 0.55f),
                Layer("M3,11.2 A2.3,2.3 0 0 1 5.3,8.9 H18.7 A2.3,2.3 0 0 1 21,11.2 V17.5 A2.5,2.5 0 0 1 18.5,20 H5.5 A2.5,2.5 0 0 1 3,17.5 Z")
            ),
            Glyph.IMAGE to listOf(
                Layer(rr(3f, 4f, 18f, 16f, 3.2f) + ci(8.5f, 9.5f, 2.1f) + "M4.5,18.2 L9.6,12.6 L13,16.2 L15.6,13.6 L19.5,18.2 Z")
            ),
            Glyph.VIDEO to listOf(
                Layer(rr(2.5f, 5f, 19f, 14f, 3.2f) + "M10,8.8 V15.2 L15.6,12 Z"),
                Layer(rr(4.2f, 6.6f, 1.4f, 1.4f, 0.4f) + rr(4.2f, 11.3f, 1.4f, 1.4f, 0.4f) + rr(4.2f, 16f, 1.4f, 1.4f, 0.4f), 0.55f)
            ),
            Glyph.MUSIC to listOf(
                Layer(ci(8f, 17.6f, 3.3f) + rr(10.2f, 3.8f, 2.1f, 13.8f, 1f)),
                Layer("M12.3,3.8 C15.2,4.3 17.8,6 18.4,9.8 C16.8,8.2 14.6,7.6 12.3,7.6 Z"),
                Layer(ci(18f, 15.4f, 2.4f), 0.55f)
            ),
            Glyph.BOOK to listOf(
                Layer("M12,6.6 C10,5 6.8,4.5 3.4,5 V18 C6.8,17.5 10,18 12,19.6 Z"),
                Layer("M12,6.6 C14,5 17.2,4.5 20.6,5 V18 C17.2,17.5 14,18 12,19.6 Z", 0.6f),
                Layer("M12,3 L12.6,4.6 L14.3,4.7 L13,5.8 L13.4,7.4 L12,6.5 L10.6,7.4 L11,5.8 L9.7,4.7 L11.4,4.6 Z", 0.9f)
            ),
            Glyph.GLOBE to listOf(
                Layer(ci(12f, 12f, 9f), 1f, 1.8f),
                Layer("M12,3 C8.5,6.5 8.5,17.5 12,21 C15.5,17.5 15.5,6.5 12,3", 1f, 1.6f),
                Layer("M3.2,12 H20.8", 1f, 1.6f),
                Layer("M4.6,7.5 H19.4 M4.6,16.5 H19.4", 0.7f, 1.3f)
            ),
            Glyph.PLAY to listOf(
                Layer(rr(2.5f, 5.5f, 19f, 13f, 4.2f) + "M10,9.2 V14.8 L15,12 Z")
            ),
            Glyph.PEOPLE to listOf(
                Layer(ci(16.6f, 8.4f, 2.6f) + "M15.6,13.2 C18.8,13 21,14.6 21,18.2 H16.9 C16.9,16.4 16.5,14.6 15.6,13.2 Z", 0.55f),
                Layer(ci(9f, 8.8f, 3.3f) + "M3,19.6 C3,15.8 5.5,14 9,14 C12.5,14 15,15.8 15,19.6 Z")
            ),
            Glyph.SHORTS to listOf(
                Layer(rr(6.2f, 2.5f, 11.6f, 19f, 3.4f) + "M10.6,8.4 V15.2 L15.4,11.8 Z" + rr(10f, 18.4f, 4f, 1.1f, 0.55f))
            ),
            Glyph.WEB to listOf(
                Layer(ci(10.5f, 10.5f, 7.6f), 1f, 1.8f),
                Layer("M10.5,2.9 C8,6 8,15 10.5,18.1 C13,15 13,6 10.5,2.9", 0.9f, 1.5f),
                Layer("M2.9,10.5 H18.1", 0.9f, 1.5f),
                Layer("M16.2,16.2 L21,21", 1f, 2.6f)
            ),
            Glyph.PIN to listOf(
                Layer("M12,2.5 C7.9,2.5 4.8,5.6 4.8,9.6 C4.8,14.6 10.2,19.6 11.3,21.2 C11.6,21.6 12.4,21.6 12.7,21.2 C13.8,19.6 19.2,14.6 19.2,9.6 C19.2,5.6 16.1,2.5 12,2.5 Z " + ci(12f, 9.6f, 3.1f))
            ),
            Glyph.GEAR to listOf(Layer(gear())),
            Glyph.CHAT to listOf(
                Layer("M5.5,3.8 H18.5 A3.5,3.5 0 0 1 22,7.3 V13.3 A3.5,3.5 0 0 1 18.5,16.8 H12.4 L7,21 V16.8 H5.5 A3.5,3.5 0 0 1 2,13.3 V7.3 A3.5,3.5 0 0 1 5.5,3.8 Z " +
                    ci(7.6f, 10.3f, 1.25f) + ci(12f, 10.3f, 1.25f) + ci(16.4f, 10.3f, 1.25f))
            ),
            Glyph.PHONE to listOf(
                Layer("M6.6,3.2 C7.2,2.6 8.2,2.8 8.6,3.5 L10.4,6.8 C10.7,7.4 10.6,8.1 10.1,8.5 L8.7,9.7 C9.7,12 11.9,14.2 14.3,15.3 L15.5,13.9 C15.9,13.4 16.6,13.3 17.2,13.6 L20.5,15.4 C21.2,15.8 21.4,16.8 20.8,17.4 C19.6,18.7 18.2,19.7 16.5,19.7 C9.9,19.5 4.5,14.1 4.3,7.5 C4.3,5.8 5.3,4.4 6.6,3.2 Z"),
                Layer("M14.6,3.6 A6,6 0 0 1 20.4,9.4", 0.75f, 1.8f),
                Layer("M14.6,7 A2.6,2.6 0 0 1 17,9.4", 0.75f, 1.8f)
            ),
            Glyph.CALENDAR to listOf(
                Layer(rr(7.2f, 2.5f, 2.2f, 4.4f, 1.1f) + rr(14.6f, 2.5f, 2.2f, 4.4f, 1.1f), 0.6f),
                Layer(rr(3f, 4.8f, 18f, 16.2f, 3.2f) + rr(3f, 8.6f, 18f, 1.3f, 0.3f) +
                    rr(6.2f, 11.6f, 2.5f, 2.5f, 0.7f) + rr(10.75f, 11.6f, 2.5f, 2.5f, 0.7f) + rr(15.3f, 11.6f, 2.5f, 2.5f, 0.7f) +
                    rr(6.2f, 15.7f, 2.5f, 2.5f, 0.7f) + rr(10.75f, 15.7f, 2.5f, 2.5f, 0.7f))
            ),
            Glyph.WIDGETS to listOf(
                Layer(rr(3f, 3f, 8f, 8f, 2.2f)),
                Layer(rr(3f, 13f, 8f, 8f, 2.2f), 0.6f),
                Layer(rr(13f, 13f, 8f, 8f, 2.2f)),
                Layer("M17,2.4 L21.6,7 L17,11.6 L12.4,7 Z", 0.6f)
            ),
            Glyph.COMPASS to listOf(
                Layer(ci(12f, 12f, 9.2f), 1f, 1.9f),
                Layer("M16,8 L13.6,13.6 L8,16 L10.4,10.4 Z"),
                Layer(ci(12f, 12f, 1.2f), 0.5f)
            ),
            Glyph.TORCH to listOf(
                Layer("M8,3.2 H16 L17.8,8.2 H6.2 Z", 0.6f),
                Layer(rr(8.2f, 8.2f, 7.6f, 13f, 2.2f) + ci(12f, 13.2f, 1.3f)),
                Layer("M3.6,3.6 L6,5.2 M20.4,3.6 L18,5.2 M12,0.9 V2.4", 0.8f, 1.6f)
            ),
            Glyph.BOOKMARK to listOf(
                Layer("M6.5,3 H17.5 A1.6,1.6 0 0 1 19,4.6 V21 L12,16.6 L5,21 V4.6 A1.6,1.6 0 0 1 6.5,3 Z")
            ),
            Glyph.DOC to listOf(
                Layer("M6.2,2.5 H13.8 L19.5,8.2 V19.5 A2,2 0 0 1 17.5,21.5 H6.5 A2,2 0 0 1 4.5,19.5 V4.2 A1.7,1.7 0 0 1 6.2,2.5 Z " +
                    rr(7.6f, 12f, 8.8f, 1.4f, 0.7f) + rr(7.6f, 15.2f, 8.8f, 1.4f, 0.7f) + rr(7.6f, 18.2f, 5.2f, 1.4f, 0.7f)),
                Layer("M13.8,2.5 V8.2 H19.5 Z", 0.55f)
            ),
            Glyph.HISTORY to listOf(
                Layer(ci(12f, 12f, 8.6f), 1f, 1.9f),
                Layer("M12,7 V12 L15.6,14.2", 1f, 2f)
            ),
            Glyph.INCOGNITO to listOf(
                Layer("M5,10.4 L7,4.2 H17 L19,10.4 Z"),
                Layer("M2.4,11.6 H21.6", 1f, 2f),
                Layer(ci(8f, 16.6f, 2.9f), 1f, 1.9f),
                Layer(ci(16f, 16.6f, 2.9f), 1f, 1.9f),
                Layer("M10.9,16.2 C11.6,15.6 12.4,15.6 13.1,16.2", 1f, 1.6f)
            ),
            Glyph.SEARCH to listOf(
                Layer(ci(10.5f, 10.5f, 6.6f), 1f, 2.4f),
                Layer("M15.6,15.6 L20.6,20.6", 1f, 2.7f)
            )
        )
    }

    private val cache = HashMap<Glyph, List<Pair<Path, Layer>>>()

    @Synchronized
    private fun paths(g: Glyph): List<Pair<Path, Layer>> = cache.getOrPut(g) {
        (defs[g] ?: emptyList()).mapNotNull { l ->
            val p = runCatching { PathParser.createPathFromPathData(l.d) }.getOrNull() ?: return@mapNotNull null
            p.fillType = Path.FillType.EVEN_ODD
            p to l
        }
    }

    /** ক্যানভাসের (left, top) থেকে size×size বর্গে আইকন আঁকে। */
    fun draw(canvas: Canvas, g: Glyph, left: Float, top: Float, size: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = (color ushr 24) and 0xFF
        canvas.save()
        canvas.translate(left, top)
        canvas.scale(size / 24f, size / 24f)
        for ((path, l) in paths(g)) {
            paint.color = color
            paint.alpha = (base * l.alpha).toInt().coerceIn(0, 255)
            if (l.stroke > 0f) {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = l.stroke
                paint.strokeCap = Paint.Cap.ROUND; paint.strokeJoin = Paint.Join.ROUND
            } else paint.style = Paint.Style.FILL
            canvas.drawPath(path, paint)
        }
        canvas.restore()
    }
}

/** Compose-এ আইকন দেখানোর জন্য। */
@Composable
fun ToolGlyph(glyph: Glyph, size: Dp, tint: Color = Color.White, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier.size(size)) {
        drawIntoCanvas { c -> ToolIcons.draw(c.nativeCanvas, glyph, 0f, 0f, this.size.width, tint.toArgb()) }
    }
}
