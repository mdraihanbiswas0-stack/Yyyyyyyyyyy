package com.omnifinder.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Telephony
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** ফোনের ভেতরের তথ্য: কন্টাক্ট (সব ফিল্ড), কল লগ, এসএমএস, ক্যালেন্ডার, ফাইলের লেখা, ব্রাউজার ডাটা। */
object DeviceData {
    private val fmt get() = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    private fun like(q: String) = "%$q%"
    private fun view(c: Context, uri: Uri, mime: String? = null) {
        val i = Intent(Intent.ACTION_VIEW).apply { if (mime != null) setDataAndType(uri, mime) else data = uri
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        runCatching { c.startActivity(i) }.onFailure { android.widget.Toast.makeText(c, "এটি খোলার মতো অ্যাপ পাওয়া যায়নি", android.widget.Toast.LENGTH_SHORT).show() }
    }

    /** বাংলা অঙ্ক (০-৯) → ইংরেজি অঙ্ক, যাতে বাংলায় নম্বর লিখেও খোঁজা যায়। */
    fun digits(q: String) = q.map { if (it in '০'..'৯') ('0' + (it - '০')) else it }.joinToString("")
    /** নম্বর খোঁজার জন্য স্পেস/ড্যাশ/ব্র্যাকেট বাদ। */
    fun phoneKey(q: String) = digits(q).filter { it.isDigit() || it == '+' }

    // ---------- কন্টাক্ট: নাম, নম্বর, ইমেইল, ঠিকানা, প্রতিষ্ঠান, নোট ----------
    fun contacts(ctx: Context, raw: String): List<Result> {
        val q = digits(raw); val pk = phoneKey(raw)
        val D = ContactsContract.Data.CONTENT_URI
        val types = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE,
            ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE)
        val inTypes = "${ContactsContract.Data.MIMETYPE} IN (${types.joinToString(",") { "?" }})"
        val ids = linkedSetOf<Long>()
        val strip = "REPLACE(REPLACE(REPLACE(REPLACE(${ContactsContract.Data.DATA1},' ',''),'-',''),'(',''),')','')"
        val sel = "(${ContactsContract.Data.DISPLAY_NAME} LIKE ? OR ${ContactsContract.Data.DATA1} LIKE ?" +
            (if (pk.length >= 2) " OR $strip LIKE ?" else "") + ") AND $inTypes"
        val args = mutableListOf(like(q), like(q)); if (pk.length >= 2) args += like(pk); args += types
        ctx.contentResolver.query(D, arrayOf(ContactsContract.Data.CONTACT_ID), sel, args.toTypedArray(), null)?.use { c ->
            while (c.moveToNext() && ids.size < 20) ids += c.getLong(0)
        }
        if (ids.isEmpty()) return emptyList()

        class Info(var name: String = "", var lookup: String = "", val lines: MutableList<String> = mutableListOf())
        val map = linkedMapOf<Long, Info>()
        val cols = arrayOf(ContactsContract.Data.CONTACT_ID, ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.LOOKUP_KEY,
            ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1)
        val sel2 = "${ContactsContract.Data.CONTACT_ID} IN (${ids.joinToString(",")}) AND $inTypes"
        ctx.contentResolver.query(D, cols, sel2, types, null)?.use { c ->
            while (c.moveToNext()) {
                val i = map.getOrPut(c.getLong(0)) { Info() }
                i.name = c.getString(1) ?: i.name; i.lookup = c.getString(2) ?: i.lookup
                val v = c.getString(4)?.trim().orEmpty(); if (v.isEmpty()) continue
                val icon = when (c.getString(3)) {
                    types[0] -> "ফোন"; types[1] -> "ইমেইল"; types[2] -> "ঠিকানা"; types[3] -> "প্রতিষ্ঠান"; types[4] -> "নোট"; else -> "ডাকনাম" }
                i.lines += "$icon: $v"
            }
        }
        return ids.mapNotNull { id -> map[id]?.let { i ->
            val uri = ContactsContract.Contacts.getLookupUri(id, i.lookup)
            Result(i.name.ifBlank { "(নামহীন)" }, i.lines.distinct().joinToString("\n"), Source.CONTACT) { c -> view(c, uri) }
        } }
    }

    // ---------- কল লগ ----------
    fun calls(ctx: Context, raw: String): List<Result> {
        val q = digits(raw); val pk = phoneKey(raw)
        val cols = arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION)
        val sel = "${CallLog.Calls.CACHED_NAME} LIKE ? OR ${CallLog.Calls.NUMBER} LIKE ?"
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, cols, sel, arrayOf(like(q), like(if (pk.length >= 2) pk else q)), "${CallLog.Calls.DATE} DESC")?.use { c ->
            while (c.moveToNext() && out.size < 20) {
                val num = c.getString(0) ?: ""; val name = c.getString(1)
                val kind = when (c.getInt(2)) { CallLog.Calls.INCOMING_TYPE -> "গৃহীত"; CallLog.Calls.OUTGOING_TYPE -> "আউটগোয়িং"
                    CallLog.Calls.MISSED_TYPE -> "মিসড"; CallLog.Calls.REJECTED_TYPE -> "রিজেক্টেড"; else -> "কল" }
                out += Result(name?.takeIf { it.isNotBlank() } ?: num, "$kind • $num • ${fmt.format(Date(c.getLong(3)))} • ${c.getLong(4)} সেকেন্ড", Source.CALL) { cx ->
                    runCatching { cx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            }
        }
        return out
    }

    // ---------- এসএমএস ----------
    fun sms(ctx: Context, raw: String): List<Result> {
        val q = digits(raw)
        val cols = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE)
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, cols, "${Telephony.Sms.BODY} LIKE ? OR ${Telephony.Sms.ADDRESS} LIKE ?",
            arrayOf(like(raw), like(q)), "${Telephony.Sms.DATE} DESC")?.use { c ->
            while (c.moveToNext() && out.size < 20) {
                val addr = c.getString(0) ?: ""
                out += Result(addr, "${c.getString(1)}\n${fmt.format(Date(c.getLong(2)))}", Source.SMS) { cx ->
                    runCatching { cx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("sms:$addr")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            }
        }
        return out
    }

    // ---------- ক্যালেন্ডার ----------
    fun calendar(ctx: Context, q: String): List<Result> {
        val E = CalendarContract.Events
        val cols = arrayOf(E._ID, E.TITLE, E.DESCRIPTION, E.EVENT_LOCATION, E.DTSTART)
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(E.CONTENT_URI, cols, "${E.DELETED}=0 AND (${E.TITLE} LIKE ? OR ${E.DESCRIPTION} LIKE ? OR ${E.EVENT_LOCATION} LIKE ?)",
            arrayOf(like(q), like(q), like(q)), "${E.DTSTART} DESC")?.use { c ->
            while (c.moveToNext() && out.size < 15) {
                val id = c.getLong(0)
                val sub = listOfNotNull(fmt.format(Date(c.getLong(4))), c.getString(3)?.takeIf { it.isNotBlank() }, c.getString(2)?.takeIf { it.isNotBlank() }).joinToString("\n")
                out += Result(c.getString(1) ?: "(শিরোনামহীন)", sub, Source.EVENT) { cx -> view(cx, ContentUris.withAppendedId(E.CONTENT_URI, id)) }
            }
        }
        return out
    }

    // ---------- ফাইলের ভেতরের লেখা (txt, csv, json, html, md, xml, log ...) ----------
    fun fileContents(ctx: Context, q: String): List<Result> {
        val uri = MediaStore.Files.getContentUri("external")
        val cols = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MIME_TYPE)
        val ext = listOf("txt", "csv", "json", "md", "html", "htm", "xml", "log", "js", "py", "java", "kt", "srt", "vcf", "ini", "yaml", "yml")
        val sel = "(${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'text/%' OR ${MediaStore.Files.FileColumns.MIME_TYPE} IN ('application/json','application/xml') OR " +
            ext.joinToString(" OR ") { "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE '%.$it'" } + ") AND ${MediaStore.Files.FileColumns.SIZE} BETWEEN 1 AND 1048576"
        val out = mutableListOf<Result>()
        var scanned = 0
        ctx.contentResolver.query(uri, cols, sel, null, "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")?.use { c ->
            while (c.moveToNext() && scanned < 400 && out.size < 15) {
                scanned++
                val id = ContentUris.withAppendedId(uri, c.getLong(0)); val mime = c.getString(2)
                val text = runCatching { ctx.contentResolver.openInputStream(id)?.bufferedReader()?.use { it.readText() } }.getOrNull() ?: continue
                val at = text.indexOf(q, ignoreCase = true); if (at < 0) continue
                val snip = text.substring(maxOf(0, at - 40), minOf(text.length, at + q.length + 60)).replace('\n', ' ')
                out += Result(c.getString(1) ?: "", "…$snip…", Source.CONTENT) { cx -> view(cx, id, mime) }
            }
        }
        return out
    }

    // ---------- OmniFinder ব্রাউজারের বুকমার্ক ও ইতিহাস ----------
    fun browser(ctx: Context, q: String): List<Result> {
        val s = BrowserStore(ctx)
        return (s.bookmarks().map { "বুকমার্ক" to it } + s.history().map { "ইতিহাস" to it })
            .filter { it.second.title.contains(q, true) || it.second.url.contains(q, true) }
            .distinctBy { it.second.url }.take(15)
            .map { (ic, p) -> Result(p.title.ifBlank { p.url }, "$ic • ${p.url}", Source.BOOKMARK) { c -> SearchEngine.url(c, p.url) } }
    }

    // ---------- টুল চাপলে (খালি সার্চে) সাম্প্রতিক/সব তালিকা ----------
    fun allContacts(ctx: Context): List<Result> {
        val C = ContactsContract.Contacts
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(C.CONTENT_URI, arrayOf(C._ID, C.DISPLAY_NAME_PRIMARY, C.LOOKUP_KEY, C.HAS_PHONE_NUMBER), null, null, "${C.DISPLAY_NAME_PRIMARY} COLLATE LOCALIZED ASC")?.use { c ->
            while (c.moveToNext() && out.size < 200) {
                val id = c.getLong(0); val name = c.getString(1)?.takeIf { it.isNotBlank() } ?: continue
                val uri = C.getLookupUri(id, c.getString(2))
                out += Result(name, if (c.getInt(3) > 0) "ফোন নম্বর আছে" else "", Source.CONTACT) { cx -> view(cx, uri) }
            }
        }
        return out
    }

    fun recentCalls(ctx: Context): List<Result> = calls(ctx, "")
    fun recentSms(ctx: Context): List<Result> = sms(ctx, "")

    fun upcomingEvents(ctx: Context): List<Result> {
        val E = CalendarContract.Events
        val cols = arrayOf(E._ID, E.TITLE, E.DESCRIPTION, E.EVENT_LOCATION, E.DTSTART)
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(E.CONTENT_URI, cols, "${E.DELETED}=0 AND ${E.DTSTART} >= ?", arrayOf((System.currentTimeMillis() - 86400000L).toString()), "${E.DTSTART} ASC")?.use { c ->
            while (c.moveToNext() && out.size < 40) {
                val id = c.getLong(0)
                val sub = listOfNotNull(fmt.format(Date(c.getLong(4))), c.getString(3)?.takeIf { it.isNotBlank() }).joinToString("\n")
                out += Result(c.getString(1) ?: "(শিরোনামহীন)", sub, Source.EVENT) { cx -> view(cx, ContentUris.withAppendedId(E.CONTENT_URI, id)) }
            }
        }
        return out
    }

    fun recentMedia(ctx: Context, uri: Uri, src: Source): List<Result> {
        val cols = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE)
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(uri, cols, null, null, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")?.use { c ->
            while (c.moveToNext() && out.size < 60) {
                val id = ContentUris.withAppendedId(uri, c.getLong(0)); val mime = c.getString(3)
                out += Result(c.getString(1) ?: "", "${c.getLong(2) / 1024} KB", src) { cx -> view(cx, id, mime) }
            }
        }
        return out
    }

    fun recentFiles(ctx: Context): List<Result> {
        val uri = MediaStore.Files.getContentUri("external")
        val cols = arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.MIME_TYPE)
        val out = mutableListOf<Result>()
        ctx.contentResolver.query(uri, cols, "${MediaStore.Files.FileColumns.MIME_TYPE} IS NOT NULL", null, "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")?.use { c ->
            while (c.moveToNext() && out.size < 60) {
                val id = ContentUris.withAppendedId(uri, c.getLong(0)); val mime = c.getString(3)
                out += Result(c.getString(1) ?: "", "${c.getLong(2) / 1024} KB", Source.FILE) { cx -> view(cx, id, mime) }
            }
        }
        return out
    }
}
