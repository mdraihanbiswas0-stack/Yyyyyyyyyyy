package com.earflow.app

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.os.*
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max

class EditorActivity : AppCompatActivity() {
    private lateinit var path: String
    private lateinit var video: VideoView
    private var dur = 0
    private var startMs = 0
    private var endMs = 0
    private val h = Handler(Looper.getMainLooper())

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun btn(t: String, color: Int, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(6), dp(12), dp(6), dp(12))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
        setOnClickListener { f() }
    }

    private fun row(vararg v: TextView): LinearLayout {
        val r = LinearLayout(this).apply { setPadding(0, dp(6), 0, 0) }
        for (x in v) r.addView(x, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        return r
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        path = intent.getStringExtra("path")!!
        MediaMetadataRetriever().also {
            it.setDataSource(path)
            dur = it.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toInt(); it.release()
        }
        endMs = dur

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF6F3FF.toInt()) }
        root.addView(TextView(this).apply {
            text = "✂ ভিডিও এডিটর"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(20), dp(18), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF5B2EFF.toInt(), 0xFFE040FB.toInt(), 0xFFFF7A00.toInt()))
        })

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        video = VideoView(this).apply { setVideoPath(path); seekTo(1) }
        body.addView(video, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val info = TextView(this).apply { textSize = 14f; setTextColor(0xFF333333.toInt()); setPadding(0, dp(8), 0, 0) }
        fun upd() { info.text = "শুরু ${startMs / 1000.0}s  •  শেষ ${endMs / 1000.0}s  •  মোট ${dur / 1000.0}s" }
        upd()
        body.addView(info)

        fun seek(label: String, init: Int, onCh: (Int) -> Unit) {
            body.addView(TextView(this).apply { text = label })
            body.addView(SeekBar(this).apply {
                max = dur; progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { if (user) { onCh(p); upd() } }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            })
        }
        seek("শুরু", 0) { startMs = minOf(it, endMs - 100); video.seekTo(startMs) }
        seek("শেষ", dur) { endMs = max(it, startMs + 100) }

        body.addView(row(
            btn("▶ প্রিভিউ", 0xFF5B2EFF.toInt()) { preview() },
            btn("✂ ট্রিম সেভ", 0xFF00B894.toInt()) { saveTrim(false) },
            btn("🔇 মিউট + ট্রিম", 0xFFFF7A00.toInt()) { saveTrim(true) }))
        body.addView(row(
            btn("📥 গ্যালারিতে সেভ", 0xFFE040FB.toInt()) {
                Toast.makeText(this, if (Util.export(this, File(path))) "Movies/EarFlow এ সেভ হয়েছে" else "সেভ ব্যর্থ", Toast.LENGTH_LONG).show()
            },
            btn("📤 শেয়ার", 0xFF0984E3.toInt()) { Util.share(this, File(path)) }))
        root.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun preview() {
        video.seekTo(startMs); video.start()
        val chk = object : Runnable {
            override fun run() {
                if (video.currentPosition >= endMs) video.pause() else if (video.isPlaying) h.postDelayed(this, 50)
            }
        }
        h.postDelayed(chk, 100)
    }

    private fun saveTrim(mute: Boolean) {
        val dst = File(File(path).parentFile, "EarFlow_${if (mute) "mute" else "trim"}_${System.currentTimeMillis()}.mp4")
        Toast.makeText(this, "সেভ হচ্ছে...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                trim(path, dst.absolutePath, startMs * 1000L, endMs * 1000L, mute)
                Util.syncAll(applicationContext); runOnUiThread { Toast.makeText(this, "সেভ হয়েছে: ${dst.name} (ফোনের স্টোরেজেও)", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                dst.delete()
                runOnUiThread { Toast.makeText(this, "ব্যর্থ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    // রি-এনকোড ছাড়া ট্রিম (দ্রুত, কোয়ালিটি লস নেই); শুরু সবচেয়ে কাছের কী-ফ্রেমে যায়
    private fun trim(src: String, dst: String, startUs: Long, endUs: Long, mute: Boolean) {
        val ex = MediaExtractor().apply { setDataSource(src) }
        val mux = MediaMuxer(dst, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val map = HashMap<Int, Int>()
        var maxBuf = 1 shl 20
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val m = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("video/") || (!mute && m.startsWith("audio/"))) {
                ex.selectTrack(i); map[i] = mux.addTrack(f)
                if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxBuf = max(maxBuf, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
        }
        mux.start()
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buf = ByteBuffer.allocate(maxBuf)
        val info = MediaCodec.BufferInfo()
        var base = -1L
        while (true) {
            info.size = ex.readSampleData(buf, 0)
            if (info.size < 0) break
            val t = ex.sampleTime
            if (t > endUs) break
            if (base < 0) base = t
            info.presentationTimeUs = max(0L, t - base)
            info.flags = ex.sampleFlags
            info.offset = 0
            mux.writeSampleData(map[ex.sampleTrackIndex]!!, buf, info)
            ex.advance()
        }
        mux.stop(); mux.release(); ex.release()
    }
}
