package com.omnifinder.app

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** ওমনি-ফাইন্ডার: ফোনের ভেতর-বাইরে সব খোঁজার স্ক্রিন। ক্যালকু-ফ্লো অ্যাপের একটি প্যাড। */
class OmniActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JonakiApp(tick.intValue) }
    }

    // উইজেট থেকে (খোলা অবস্থায়) নতুন টুল/ফোকাস অনুরোধ এলে
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tick.intValue = tick.intValue + 1
    }
}

private val filterOf = mapOf(
    Tool.APPS to setOf(Source.APP), Tool.CONTACTS to setOf(Source.CONTACT), Tool.FILES to setOf(Source.FILE, Source.CONTENT), Tool.SETTINGS to setOf(Source.SETTING),
    Tool.MESSAGES to setOf(Source.SMS), Tool.CALLS to setOf(Source.CALL), Tool.CALENDAR to setOf(Source.EVENT),
    Tool.PHOTOS to setOf(Source.PHOTO), Tool.VIDEOS to setOf(Source.VIDEO), Tool.AUDIO to setOf(Source.AUDIO)
)

/** যে টুলের জন্য কোন পারমিশন লাগে */
private fun permsFor(t: Tool): List<String> = when (t) {
    Tool.CONTACTS -> listOf(Manifest.permission.READ_CONTACTS)
    Tool.CALLS -> listOf(Manifest.permission.READ_CALL_LOG)
    Tool.MESSAGES -> listOf(Manifest.permission.READ_SMS)
    Tool.CALENDAR -> listOf(Manifest.permission.READ_CALENDAR)
    Tool.PHOTOS -> if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    Tool.VIDEOS -> if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_VIDEO) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    Tool.AUDIO -> if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_AUDIO) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    Tool.FILES -> if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    else -> emptyList()
}

@Composable
fun JonakiApp(intentTick: Int) {
    val ctx = LocalContext.current
    val act = ctx as? ComponentActivity
    val prefs = remember { Prefs(ctx) }
    var ver by remember { mutableIntStateOf(0) }          // সেটিংস বদলালে রিফ্রেশ
    val initial = remember { act?.intent?.getStringExtra("q") ?: act?.intent?.getStringExtra(SearchManager.QUERY) ?: "" }
    var query by remember { mutableStateOf(initial) }
    var tool by remember { mutableStateOf<Tool?>(null) }
    var results by remember { mutableStateOf(linkedMapOf<Source, List<Result>>()) }
    var extra by remember { mutableStateOf<List<Result>>(emptyList()) }
    var showSettings by remember { mutableStateOf(false) }
    var showWidgets by remember { mutableStateOf(false) }
    val focusReq = remember { androidx.compose.ui.focus.FocusRequester() }
    var torchOn by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var pendingTool by remember { mutableStateOf<Tool?>(null) }

    fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ver++ }
    fun askPermissions(only: List<String>? = null) {
        val p = mutableListOf<String>()
        if (only != null) p += only else {
            p += listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_SMS, Manifest.permission.READ_CALENDAR)
            if (Build.VERSION.SDK_INT >= 33) p += listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
            else p += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        permLauncher.launch(p.filter { !granted(it) }.toTypedArray().ifEmpty { p.toTypedArray() })
    }
    // অ্যাপ খুললেই দ্রুত অ্যাক্সেসের পারমিশন চাওয়া (একবার)
    LaunchedEffect(Unit) { if (!granted(Manifest.permission.READ_CONTACTS) && !prefs.askedPerms) { prefs.askedPerms = true; askPermissions() } }

    fun labelImage(img: InputImage) {
        status = "ছবি বিশ্লেষণ হচ্ছে…"
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(img)
            .addOnSuccessListener { l ->
                if (l.isEmpty()) status = "ছবিতে চেনার মতো কিছু পাওয়া যায়নি"
                else { query = l.take(2).joinToString(" ") { it.text }; tool = null; status = "ছবিতে পাওয়া গেছে: $query" }
            }
            .addOnFailureListener { status = "ছবি চেনা যায়নি" }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        bmp?.let { labelImage(InputImage.fromBitmap(it, 0)) } }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { runCatching { labelImage(InputImage.fromFilePath(ctx, it)) }.onFailure { status = "ছবিটি পড়া যায়নি" } } }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { query = it; tool = null; status = "শোনা গেছে: $it" } }

    val cm = remember { ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    DisposableEffect(Unit) {
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { torchOn = enabled }
        }
        runCatching { cm.registerTorchCallback(cb, null) }
        onDispose { runCatching { cm.unregisterTorchCallback(cb) } }
    }
    fun torchId(): String? = runCatching {
        cm.cameraIdList.firstOrNull { id ->
            val ch = cm.getCameraCharacteristics(id)
            ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true && ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    fun onTool(t: Tool) {
        when (t) {
            Tool.CAMERA -> runCatching { camera.launch(null) }.onFailure { status = "ক্যামেরা অ্যাপ পাওয়া যায়নি" }
            Tool.GALLERY -> runCatching { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }.onFailure { status = "গ্যালারি খোলা যায়নি" }
            Tool.QR -> runCatching {
                GmsBarcodeScanning.getClient(ctx).startScan()
                    .addOnSuccessListener { b ->
                        val raw = b.rawValue ?: ""
                        if (raw.startsWith("http://") || raw.startsWith("https://")) {
                            status = "QR-এ লিংক পাওয়া গেছে"; tool = null
                            extra = listOf(Result("লিংক খুলুন", raw, Source.WEB) { c -> SearchEngine.url(c, raw) })
                        } else { query = raw; tool = null; status = "QR: $raw" }
                    }
                    .addOnCanceledListener { status = "" }
                    .addOnFailureListener { status = "QR স্ক্যান করা যায়নি — গুগল প্লে সার্ভিস লাগে" }
            }.onFailure { status = "QR স্ক্যানার চালু হয়নি" }
            Tool.VOICE -> runCatching {
                voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD"))
            }.onFailure { status = "এই ফোনে ভয়েস-ইনপুট (গুগল) নেই" }
            Tool.WIDGETS -> showWidgets = true
            Tool.BROWSER -> ctx.startActivity(Intent(ctx, BrowserActivity::class.java))
            Tool.TORCH -> {
                val id = torchId()
                if (id == null) status = "এই ফোনে টর্চ (ফ্ল্যাশ) পাওয়া যায়নি"
                else runCatching { cm.setTorchMode(id, !torchOn) }.onFailure { status = "টর্চ চালু করা যায়নি (ক্যামেরা ব্যবহার হচ্ছে?)" }
            }
            else -> {
                if (t.online) { SearchEngine.openOnline(ctx, t, query); tool = null }
                else {
                    val need = permsFor(t).filter { !granted(it) }
                    if (need.isNotEmpty()) { pendingTool = t; askPermissions(need) }
                    tool = if (tool == t) null else t
                }
            }
        }
    }

    // ধাপে ধাপে সার্চ — প্রতিটি উৎসের ফলাফল আসামাত্র দেখায় (লেখা থামার ০.২৫ সেকেন্ড পরে)
    LaunchedEffect(query, tool, ver) {
        results = linkedMapOf()
        val t = tool
        if (query.isBlank()) {
            if (t != null) {
                val m = withContext(Dispatchers.IO) { runCatching { SearchEngine.browse(ctx, t) }.getOrNull() }
                if (m != null) results = LinkedHashMap<Source, List<Result>>().also { l -> m.forEach { (s, r) -> l[s] = r } }
            }
            return@LaunchedEffect
        }
        extra = emptyList()
        delay(250)
        SearchEngine.search(ctx, query) { granted(it) }.collect { (src, list) ->
            val allow = t?.let { filterOf[it] }
            if (list.isNotEmpty() && (allow == null || src in allow)) results = LinkedHashMap(results).also { it[src] = list }
        }
    }

    // উইজেট/ইন্টেন্ট থেকে আসা অনুরোধ (ফোকাস, টুল)
    LaunchedEffect(intentTick) {
        val it = act?.intent ?: return@LaunchedEffect
        if (intentTick > 0) it.getStringExtra("q")?.let { q -> query = q }
        if (it.getBooleanExtra("focus", false)) { it.removeExtra("focus"); runCatching { focusReq.requestFocus() } }
        it.getStringExtra("tool")?.let { n ->
            it.removeExtra("tool")
            Tool.values().find { x -> x.name == n }?.let { x -> onTool(x) }
        }
    }
    val tools = remember(ver) { prefs.tools }
    val name = remember(ver) { prefs.userName }

    Box(Modifier.fillMaxSize().background(Color(remember(ver) { prefs.appBg }))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ act?.finish() }) { Icon(Icons.Filled.ArrowBack, "ফিরে যান", tint = Color.White) }
                Text(if (name.isBlank()) "ওমনি-ফাইন্ডার" else "ওমনি-ফাইন্ডার · $name", color = Color(0xFFFFE066), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton({ showSettings = true }) { Icon(Icons.Filled.Settings, "সেটিংস", tint = Color.White) }
            }
            Spacer(Modifier.height(8.dp))

            // সার্চ বার: [জোনাকি] [লেখা] [সার্চ আইকন]
            Row(Modifier.fillMaxWidth().background(Color(prefs.barBg), RoundedCornerShape(30.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Firefly(46.dp)
                Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    if (query.isEmpty()) Text("জোনাকিকে বলুন… যেকোনো কিছু খুঁজুন", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                    BasicTextField(query, { query = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        cursorBrush = SolidColor(Color.White), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { ver++ }), modifier = Modifier.fillMaxWidth().focusRequester(focusReq))
                }
                if (query.isNotEmpty()) Box(Modifier.size(34.dp).clickable { query = ""; extra = emptyList(); status = "" }, contentAlignment = Alignment.Center) {
                    Text("×", color = Color.White.copy(alpha = 0.7f), fontSize = 24.sp) }
                Box(Modifier.size(40.dp).clickable { ver++ }, contentAlignment = Alignment.Center) { ToolGlyph(Glyph.SEARCH, 26.dp, Color(0xFFFFE066)) }
            }
            if (status.isNotBlank()) Text(status, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, start = 8.dp))
            Spacer(Modifier.height(12.dp))
            ToolBar(tools, prefs, tool, if (torchOn) setOf(Tool.TORCH) else emptySet()) { onTool(it) }
            Spacer(Modifier.height(12.dp))

            val hasAny = results.isNotEmpty() || extra.isNotEmpty()
            if (!hasAny && query.isBlank()) {
                Text("সার্চ বক্সে লিখুন, অথবা নিচের কোনো টুলে চাপুন — অ্যাপ, কন্টাক্ট, ফাইল, ছবি, ওয়েব, কুরআন সব এখানে।", color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp, modifier = Modifier.padding(8.dp))
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (extra.isNotEmpty()) itemsIndexed(extra, key = { i, _ -> "x$i" }) { _, r -> ResultCard(r) { r.open(ctx) } }
                results.forEach { (src, list) ->
                    item(key = "h${src.name}") {
                        Row(Modifier.padding(top = 10.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            ToolGlyph(src.glyph, 18.dp, Color(0xFFFFE066))
                            Text("  ${src.title}  (${list.size})", color = Color(0xFFFFE066), fontWeight = FontWeight.Bold)
                        }
                    }
                    itemsIndexed(list, key = { i, _ -> "${src.name}#$i" }) { _, r -> ResultCard(r) { r.open(ctx) } }
                }
            }
        }
        if (showSettings) SettingsScreen(prefs, onChange = { ver++; WidgetUpdater.updateAll(ctx) },
            onWidgets = { showWidgets = true },
            onPermissions = { askPermissions() },
            onAllFiles = { runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))) } },
            onClose = { showSettings = false })
        if (showWidgets) WidgetsDialog { showWidgets = false }
    }
}

@Composable
private fun ResultCard(r: Result, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(12.dp)) {
        Text(r.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 2)
        if (r.subtitle.isNotBlank()) Text(r.subtitle, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 6)
    }
}
