package com.earflow.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

// টিউটোরিয়ালে ইশারা করার ভাসমান বিন্দু। ধরে টানলে সরে, ট্যাপ করলে রিং-পালস হয়।
class PointerView(c: Context, private val size: Int, color: Int) : View(c) {
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; alpha = 210 }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 7f; this.color = color
    }
    private var pulse = 0f

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = size * 0.22f
        c.drawCircle(cx, cy, r, dot)
        if (pulse > 0f) {
            ring.alpha = ((1 - pulse) * 255).toInt()
            c.drawCircle(cx, cy, r + size * 0.28f * pulse, ring)
        }
    }

    fun pulse() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }
}
