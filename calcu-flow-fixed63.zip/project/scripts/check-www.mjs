#!/usr/bin/env node
// বিল্ডের আগে www/index.html ও bridge ফাইলের দ্রুত স্বাস্থ্য-পরীক্ষা।
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const www = path.join(root, "www");
let bad = 0;
const fail = (m) => {
  console.error("✘", m);
  bad++;
};

const idx = path.join(www, "index.html");
if (!fs.existsSync(idx)) fail("www/index.html নেই");
else {
  const html = fs.readFileSync(idx, "utf8");
  // type="text/plain" ব্লকে (iframe-এর উৎস) ভেতরের <script> থাকে — সেগুলো বাদ
  const stripped = html.replace(/<script[^>]*type="text\/plain"[^>]*>[\s\S]*?<\/script>/g, "");
  if (!html.includes("window.JN")) fail("index.html-এ নেটিভ ব্রিজ (JN) যুক্ত নেই");
  // ইনলাইন স্ক্রিপ্টগুলোর সিনট্যাক্স
  let n = 0;
  for (const m of stripped.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)) {
    if (/\ssrc=/.test(m[1])) continue;
    n++;
    try {
      new vm.Script(m[2]);
    } catch (e) {
      fail(`ইনলাইন স্ক্রিপ্ট #${n} এ সিনট্যাক্স ত্রুটি: ${e.message}`);
    }
  }
  console.log(`✔ index.html (${(html.length / 1024).toFixed(0)} KB, ${n} স্ক্রিপ্ট)`);
}
process.exit(bad ? 1 : 0);
