package com.omnifinder.app

import androidx.compose.ui.graphics.Color

/** প্রতিটি টুলের নিজস্ব আইকন (নিজে আঁকা) ও ডিফল্ট রঙ — কোনো কোম্পানির লোগো বা ইমোজি নেই। */
enum class Tool(val label: String, val glyph: Glyph, val defColor: Long) {
    CAMERA("ক্যামেরা", Glyph.CAMERA, 0xFFFF5F6D),
    GALLERY("গ্যালারি", Glyph.GALLERY, 0xFFFFB347),
    QR("QR স্ক্যান", Glyph.QR, 0xFF00C9A7),
    VOICE("ভয়েস", Glyph.MIC, 0xFF845EC2),
    APPS("অ্যাপস", Glyph.APPS, 0xFF2C9CFF),
    CONTACTS("কন্টাক্ট", Glyph.CONTACT, 0xFF4ADE80),
    FILES("ফাইল", Glyph.FOLDER, 0xFFFFC857),
    PHOTOS("ছবি", Glyph.IMAGE, 0xFFFF7EB6),
    VIDEOS("ভিডিও", Glyph.VIDEO, 0xFFFF6B35),
    AUDIO("অডিও", Glyph.MUSIC, 0xFF9B5DE5),
    QURAN("কুরআন", Glyph.BOOK, 0xFF1FAB89),
    WIKI("উইকি", Glyph.GLOBE, 0xFF5AA9E6),
    YOUTUBE("ইউটিউব", Glyph.PLAY, 0xFFFF3B3B),
    FACEBOOK("ফেসবুক", Glyph.PEOPLE, 0xFF3D7BFF),
    TIKTOK("টিকটক", Glyph.SHORTS, 0xFFEC4899),
    WEB("ওয়েব", Glyph.WEB, 0xFF38BDF8),
    MAPS("ম্যাপ", Glyph.PIN, 0xFFEF4444),
    SETTINGS("সেটিংস", Glyph.GEAR, 0xFF94A3B8),
    MESSAGES("মেসেজ", Glyph.CHAT, 0xFF34D399),
    CALLS("কল লগ", Glyph.PHONE, 0xFF60A5FA),
    CALENDAR("ক্যালেন্ডার", Glyph.CALENDAR, 0xFFF97316),
    WIDGETS("উইজেট", Glyph.WIDGETS, 0xFFA78BFA),
    BROWSER("ব্রাউজার", Glyph.COMPASS, 0xFF22D3EE),
    TORCH("টর্চ", Glyph.TORCH, 0xFFFACC15);

    /** সার্চ-বারের টুল, যেগুলো সরাসরি ওয়েবসাইট/অ্যাপে নিয়ে যায় */
    val online: Boolean get() = this in setOf(YOUTUBE, FACEBOOK, TIKTOK, WEB, MAPS, WIKI, QURAN)
}

/** ফলাফল কোন উৎস থেকে এসেছে। */
enum class Source(val title: String, val glyph: Glyph) {
    APP("ইনস্টল করা অ্যাপ", Glyph.APPS), CONTACT("কন্টাক্ট", Glyph.CONTACT), FILE("ফাইল", Glyph.FOLDER),
    PHOTO("ছবি", Glyph.IMAGE), VIDEO("ভিডিও", Glyph.VIDEO), AUDIO("অডিও", Glyph.MUSIC),
    SETTING("সেটিংস অপশন", Glyph.GEAR), SMS("এসএমএস", Glyph.CHAT), CALL("কল লগ", Glyph.PHONE), EVENT("ক্যালেন্ডার", Glyph.CALENDAR),
    CONTENT("ফাইলের ভেতরের লেখা", Glyph.DOC), BOOKMARK("ব্রাউজার বুকমার্ক/ইতিহাস", Glyph.BOOKMARK),
    QURAN("কুরআন", Glyph.BOOK), WIKI("উইকিপিডিয়া", Glyph.GLOBE), WEB("অনলাইন", Glyph.WEB),
    YOUTUBE("ইউটিউব", Glyph.PLAY), FACEBOOK("ফেসবুক", Glyph.PEOPLE), TIKTOK("টিকটক", Glyph.SHORTS), MAPS("ম্যাপ", Glyph.PIN)
}

val DefaultTools = listOf(
    Tool.CAMERA, Tool.GALLERY, Tool.QR, Tool.VOICE, Tool.APPS, Tool.SETTINGS, Tool.CONTACTS,
    Tool.FILES, Tool.QURAN, Tool.YOUTUBE, Tool.FACEBOOK, Tool.TIKTOK, Tool.WEB, Tool.BROWSER, Tool.TORCH
)

fun Long.c() = Color(this)
