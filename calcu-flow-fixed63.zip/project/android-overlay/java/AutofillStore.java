package __APP_ID__;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * অটোফিলের জন্য লগইন-তালিকা ফোনের Android Keystore-এ (AES-256-GCM) এনক্রিপ্ট করে রাখে।
 * চাবি ডিভাইসের বাইরে যায় না। শুধু "অ্যাপে ফিল" চালু থাকলেই এখানে ডেটা থাকে।
 */
final class AutofillStore {

    private static final String PREFS = "jn_autofill";
    private static final String KEY_DATA = "d";
    private static final String KEY_PEND = "pnd";
    private static final String ALIAS = "jn_autofill_key_v1";

    static final class Entry {
        String id = "";
        String title = "";
        String url = "";
        String user = "";
        String pass = "";
        boolean draft = false;
    }

    private AutofillStore() {
    }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    static synchronized void save(Context c, String json) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV();
        byte[] ct = cipher.doFinal(json.getBytes(StandardCharsets.UTF_8));
        String v = Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_DATA, v).apply();
    }

    static synchronized void clear(Context c) {
        try {
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_DATA).apply();
        } catch (Throwable ignored) {
        }
    }

    static synchronized List<Entry> load(Context c) {
        List<Entry> out = new ArrayList<>();
        try {
            String v = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, null);
            if (v != null) out.addAll(parse(dec(v)));
        } catch (Throwable ignored) {
        }
        // ভল্টে ঢোকার অপেক্ষায় থাকা নতুন সেভগুলোও সাথে সাথে অটোফিলে মেলে
        for (Entry e : loadPending(c)) {
            boolean dup = false;
            for (Entry o : out) {
                if (o.id.equals(e.id) || (hostOf(o.url).equals(hostOf(e.url)) && o.user.length() > 0 && o.user.equals(e.user))) { dup = true; break; }
            }
            if (!dup) out.add(0, e);
        }
        return out;
    }

    private static String enc(String plain) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV();
        byte[] ct = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
    }

    private static String dec(String v) throws Exception {
        int i = v.indexOf(':');
        byte[] iv = Base64.decode(v.substring(0, i), Base64.NO_WRAP);
        byte[] ct = Base64.decode(v.substring(i + 1), Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
    }

    private static List<Entry> parse(String json) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(json);
            for (int k = 0; k < a.length(); k++) {
                JSONObject o = a.optJSONObject(k);
                if (o == null) continue;
                Entry e = new Entry();
                e.id = o.optString("id", "");
                e.title = o.optString("t", "");
                e.url = o.optString("u", "");
                e.user = o.optString("n", "");
                e.pass = o.optString("p", "");
                e.draft = o.optInt("d", 0) == 1;
                if (e.pass.length() > 0 || e.user.length() > 0) out.add(e);
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    static String toJson(List<Entry> l) {
        JSONArray a = new JSONArray();
        try {
            for (Entry e : l) {
                JSONObject o = new JSONObject();
                o.put("id", e.id);
                o.put("t", e.title);
                o.put("u", e.url);
                o.put("n", e.user);
                o.put("p", e.pass);
                o.put("d", e.draft ? 1 : 0);
                a.put(o);
            }
        } catch (Throwable ignored) {
        }
        return a.toString();
    }

    /* ---------- নতুন সেভ-করা পাসওয়ার্ড (ভল্টে ঢোকার অপেক্ষায়) ---------- */

    static synchronized List<Entry> loadPending(Context c) {
        try {
            String v = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PEND, null);
            if (v == null) return new ArrayList<>();
            return parse(dec(v));
        } catch (Throwable t) {
            return new ArrayList<>();
        }
    }

    private static void savePending(Context c, List<Entry> l) throws Exception {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (l.isEmpty()) sp.edit().remove(KEY_PEND).apply();
        else sp.edit().putString(KEY_PEND, enc(toJson(l))).apply();
    }

    /** একই সাইট+ইউজার থাকলে পাসওয়ার্ড বদলায়; সাজেস্ট করা ড্রাফট থাকলে সেটিতে ইউজার যোগ হয় */
    static synchronized void upsertPending(Context c, Entry n) throws Exception {
        List<Entry> l = loadPending(c);
        String host = hostOf(n.url);
        Entry hit = null;
        for (Entry e : l) {
            if (!hostOf(e.url).equals(host)) continue;
            if (n.user.length() > 0 && n.user.equals(e.user)) { hit = e; break; }
            if (e.draft && e.pass.equals(n.pass)) { hit = e; break; }
        }
        if (hit == null) {
            if (n.id.length() == 0) n.id = "n" + System.currentTimeMillis();
            l.add(n);
        } else {
            if (n.user.length() > 0) hit.user = n.user;
            hit.pass = n.pass;
            if (n.title.length() > 0) hit.title = n.title;
            if (!n.draft) hit.draft = false;
        }
        savePending(c, l);
    }

    static synchronized void clearPending(Context c, java.util.Set<String> ids) {
        try {
            if (ids == null) {
                c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PEND).apply();
                return;
            }
            List<Entry> l = loadPending(c);
            List<Entry> keep = new ArrayList<>();
            for (Entry e : l) if (!ids.contains(e.id)) keep.add(e);
            savePending(c, keep);
        } catch (Throwable ignored) {
        }
    }

    /** ঠিকানা থেকে হোস্ট (www ছাড়া, ছোট হাতের) */
    static String hostOf(String u) {
        if (u == null) return "";
        String s = u.trim().toLowerCase();
        int p = s.indexOf("://");
        if (p >= 0) s = s.substring(p + 3);
        int e = s.length();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '/' || ch == '?' || ch == '#' || ch == ':') {
                e = i;
                break;
            }
        }
        s = s.substring(0, e);
        if (s.startsWith("www.")) s = s.substring(4);
        return s;
    }
}
