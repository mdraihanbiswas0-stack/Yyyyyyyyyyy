package com.earflow.app

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.*
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class CallRecordService : Service() {
    @Volatile private var running = false
    private var startedAt = 0L
    private val main = Handler(Looper.getMainLooper())

    private class Opened(val rec: AudioRecord, val rate: Int, val frame: Int, val pre: List<ShortArray>)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg(running)
        when (intent?.action) {
            "START" -> startRec(intent.getStringExtra("number") ?: "", intent.getBooleanExtra("incoming", true))
            "STOP" -> running = false
            "QUIT" -> { running = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_STICKY
    }

    private fun startFg(rec: Boolean) {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("call", "Call recorder", NotificationManager.IMPORTANCE_LOW))
        val b = NotificationCompat.Builder(this, "call")
            .setContentTitle(if (rec) "🔴 কল রেকর্ড হচ্ছে" else "ইয়ার-ফ্লো: অটো কল রেকর্ড চালু")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
        if (rec) {
            b.setUsesChronometer(true).setWhen(startedAt)
            b.addAction(0, "⏹ থামান", PendingIntent.getService(this, 7,
                Intent(this, CallRecordService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE))
        }
        val n = b.build()
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun clean(s: String) = s.replace(Regex("[^\\p{L}\\p{N}+ ]"), "_")

    private fun fileName(name: String, num: String, incoming: Boolean, time: String) =
        "${clean(name)}_${num.filter { it.isDigit() || it == '+' }.ifEmpty { "NoNumber" }}_${if (incoming) "IN" else "OUT"}_$time.m4a"

    // ---------- মাইক খোলা: যে সোর্সে আসল আওয়াজ আছে সেটিই বেছে নেয় ----------
    private fun tryOpen(src: Int, rate: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        return try {
            val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, rate * 2))
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); null }
            else {
                r.startRecording()
                if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) r else { r.release(); null }
            }
        } catch (e: Exception) { null }
    }

    private fun openRecorder(p: SharedPreferences): Opened? {
        val all = intArrayOf(MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.CAMCORDER, MediaRecorder.AudioSource.MIC)
        val last = p.getInt("lastsrc", -1)
        val order = (if (last in all) listOf(last) else emptyList()) + all.filter { it != last }

        for (src in order) {
            var rate = 16000
            var r = tryOpen(src, rate)
            if (r == null) { rate = 44100; r = tryOpen(src, rate) }
            if (r == null) continue
            val frame = if (rate == 16000) 1024 else 3072
            val tmp = ShortArray(frame)
            val pre = ArrayList<ShortArray>()
            var peak = 0
            val end = SystemClock.elapsedRealtime() + 700
            while (running && SystemClock.elapsedRealtime() < end) {
                val n = r.read(tmp, 0, frame)
                if (n > 0) {
                    pre.add(tmp.copyOf(n))
                    for (i in 0 until n) { val a = abs(tmp[i].toInt()); if (a > peak) peak = a }
                } else if (n < 0) break
            }
            // পুরো ০ = মাইক ব্লক (Android সাইলেন্ট ডাটা দেয়) → পরের সোর্স
            if (peak > 0) {
                p.edit().putInt("lastsrc", src).apply()
                return Opened(r, rate, frame, pre)
            }
            try { r.stop() } catch (_: Exception) {}
            r.release()
            if (!running) return null
        }
        val m = tryOpen(MediaRecorder.AudioSource.MIC, 16000) ?: return null
        return Opened(m, 16000, 1024, emptyList())
    }

    private fun startRec(numberIn: String, incoming: Boolean) {
        if (running) return
        val p = getSharedPreferences("ef", MODE_PRIVATE)
        val cname = contactName(numberIn)
        val mode = p.getInt("recmode", 0)
        if (mode == 1 && cname != null) return
        if (mode == 2 && cname == null && numberIn.isNotEmpty()) return

        running = true
        startedAt = System.currentTimeMillis()
        startFg(true)

        val maxGain = p.getInt("gain", 20).toFloat()
        val kbps = p.getInt("callkbps", 48)
        val audio = getSystemService(AudioManager::class.java)
        val oldSpeaker = audio.isSpeakerphoneOn
        val oldVol = audio.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
        // অপর প্রান্তের আওয়াজ মাইকে ধরতে: স্পিকার অন + ভলিউম ম্যাক্স
        if (p.getBoolean("speaker", true)) {
            audio.isSpeakerphoneOn = true
            audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL, audio.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
        }

        val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = File(getExternalFilesDir(null), "calls").apply { mkdirs() }
        val file = File(dir, fileName(cname ?: "Unknown", numberIn, incoming, time))

        Thread {
            var rec: AudioRecord? = null
            var writer: AacWriter? = null
            var peak = 0
            var ms = 0L
            var failed = false
            try {
                val o = openRecorder(p)
                if (o == null) failed = true
                else {
                    rec = o.rec
                    if (p.getBoolean("ns", false) && NoiseSuppressor.isAvailable())
                        NoiseSuppressor.create(o.rec.audioSessionId)?.enabled = true
                    val w = AacWriter(file.absolutePath, o.rate, kbps * 1000)
                    writer = w
                    val dsp = Dsp(o.rate, maxGain)
                    val out = ByteArray(o.frame * 2 + 16)
                    for (c in o.pre) w.write(out, dsp.process(c, c.size, out))
                    val buf = ShortArray(o.frame)
                    while (running) {
                        val n = o.rec.read(buf, 0, buf.size)
                        if (n > 0) w.write(out, dsp.process(buf, n, out)) else if (n < 0) break
                    }
                    peak = dsp.peak
                    ms = w.durationMs
                }
            } catch (e: Exception) {
                failed = true
            } finally {
                running = false
                try { rec?.stop() } catch (_: Exception) {}
                rec?.release()
                writer?.finish()
                audio.isSpeakerphoneOn = oldSpeaker
                audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL, oldVol, 0)
                main.post {
                    if (failed || (ms > 0 && peak == 0)) { file.delete(); problem() }
                    else if (p.getBoolean("skipshort", true) && ms < 3000) file.delete()
                    else main.postDelayed({ fixName(file, numberIn, incoming, time); Thread { try { Thread.sleep(6000) } catch (_: Exception) {}; Util.syncAll(applicationContext) }.start() }, 2500)
                    if (p.getBoolean("auto", false)) startFg(false)
                }
            }
        }.start()
    }

    private fun problem() {
        val n = NotificationCompat.Builder(this, "call").setContentTitle("কল রেকর্ড হয়নি")
            .setContentText("মাইক ব্লক হয়েছে — সেটআপ থেকে অ্যাক্সেসিবিলিটি চালু করুন")
            .setSmallIcon(android.R.drawable.stat_notify_error).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(3, n)
    }

    // নম্বর না পেলে কল লগ থেকে নিয়ে ফাইলের নাম ঠিক করা
    private fun fixName(file: File, numberIn: String, incoming: Boolean, time: String) {
        if (numberIn.isNotEmpty() || !file.exists()) return
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME), null, null, "date DESC")?.use {
                if (it.moveToFirst()) {
                    val num = it.getString(0) ?: return
                    val name = it.getString(1) ?: contactName(num) ?: "Unknown"
                    file.renameTo(File(file.parentFile, fileName(name, num, incoming, time)))
                }
            }
        } catch (_: Exception) {}
    }

    private fun contactName(number: String): String? {
        if (number.isEmpty()) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) { null }
    }
}
