#!/usr/bin/env node
/**
 * বিল্ডের পরে মার্জ-হওয়া AndroidManifest দেখে যাচাই করে: সব উইজেট, অ্যাক্টিভিটি, সার্ভিস ও অনুমতি আছে কিনা।
 *   node scripts/verify-build.mjs <merged-manifest-path> [features.json]
 * ঘাটতি পেলে ::warning:: দেখায় (বিল্ড থামায় না — APK তবু তৈরি হয়)।
 */
import fs from "node:fs";
const [, , mp, fj] = process.argv;
if (!mp || !fs.existsSync(mp)) { console.log("::warning::মার্জ-করা ম্যানিফেস্ট পাওয়া যায়নি — যাচাই বাদ"); process.exit(0); }
const man = fs.readFileSync(mp, "utf8");
const inv = fj && fs.existsSync(fj) ? JSON.parse(fs.readFileSync(fj, "utf8")) : { pads: [], permissions: [] };
const cap = (x) => x[0].toUpperCase() + x.slice(1);
let bad = 0;
const need = (ok, what) => { console.log(`${ok ? "✔" : "✘"} ${what}`); if (!ok) { bad++; console.log(`::warning::ম্যানিফেস্টে নেই: ${what}`); } };
console.log("— প্যাড-উইজেট —");
for (const p of inv.pads || []) need(new RegExp(`\\.Widget${cap(p.id)}"`).test(man), `Widget${cap(p.id)} (${p.label})`);
console.log("— ওমনি-ফাইন্ডার উইজেট ও স্ক্রিন —");
for (const c of ["SearchWidget", "BarWidget", "ToolsWidget", "OmniActivity", "BrowserActivity"]) need(man.includes(`com.omnifinder.app.${c}`), c);
console.log("— ইয়ার-ফ্লো (রেকর্ডার) —");
for (const c of ["EarActivity", "CallRecordService", "ScreenRecordService", "CallReceiver", "EarFlowAccessibilityService"]) need(man.includes(`com.earflow.app.${c}`), c);
console.log("— অটোফিল —");
need(/android\.permission\.BIND_AUTOFILL_SERVICE/.test(man), "অটোফিল সার্ভিস (BIND_AUTOFILL_SERVICE)");
console.log("— অনুমতি —");
for (const perm of inv.permissions || []) need(man.includes(`android.permission.${perm}`), perm);
console.log(bad ? `\n${bad}টি ঘাটতি (উপরে ✘)` : "\nসব যাচাই পাস ✔");
