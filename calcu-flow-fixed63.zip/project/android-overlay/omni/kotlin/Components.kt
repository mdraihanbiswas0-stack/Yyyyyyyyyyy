package com.omnifinder.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** ৩ডি-ধাঁচের রঙিন টুল আইকন: গ্রেডিয়েন্ট + ছায়া + উপরের হাইলাইট। */
@Composable
fun ToolTile(tool: Tool, color: Long, selected: Boolean = false, onClick: () -> Unit) {
    val base = Color(color)
    Column(Modifier.width(68.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(56.dp)
                .shadow(10.dp, RoundedCornerShape(18.dp), ambientColor = base, spotColor = base)
                .background(Brush.verticalGradient(listOf(lerp(base, Color.White, 0.35f), base, lerp(base, Color.Black, 0.35f))), RoundedCornerShape(18.dp))
                .border(if (selected) BorderStroke(2.5.dp, Color.White) else BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.align(Alignment.TopCenter).padding(top = 3.dp).fillMaxWidth(0.8f).height(14.dp)
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.45f), Color.Transparent)), RoundedCornerShape(12.dp)))
            ToolGlyph(tool.glyph, 30.dp)
        }
        Spacer(Modifier.height(5.dp))
        Text(tool.label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

/** বাম↔ডান স্ক্রল করা যায় এমন টুলবার। */
@Composable
fun ToolBar(tools: List<Tool>, prefs: Prefs, selected: Tool?, lit: Set<Tool> = emptySet(), onTool: (Tool) -> Unit) {
    LazyRow(
        Modifier.fillMaxWidth().background(Color(prefs.barBg), RoundedCornerShape(24.dp)).padding(vertical = 12.dp),
        contentPadding = PaddingValues(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) { items(tools) { t -> ToolTile(t, prefs.toolColor(t), selected == t || t in lit) { onTool(t) } } }
}

private val Swatches = listOf(
    0xFFFF5F6D, 0xFFFF7EB6, 0xFFFFB347, 0xFFFFC857, 0xFF4ADE80, 0xFF1FAB89, 0xFF00C9A7, 0xFF38BDF8,
    0xFF2C9CFF, 0xFF3D7BFF, 0xFF845EC2, 0xFFEC4899, 0xFFEF4444, 0xFF0B1026, 0xFF151B3D, 0xFF1E293B,
    0xFF111111, 0xFFFFFFFF, 0xFF0F3D2E, 0xFF3B0F2E
)

/** যেকোনো রঙ: সোয়াচ বা হেক্স কোড (#RRGGBB)। */
@Composable
fun ColorPicker(current: Long, onPick: (Long) -> Unit) {
    var hex by remember(current) { mutableStateOf("%06X".format(current and 0xFFFFFF)) }
    Column {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Swatches) { c ->
                Box(Modifier.size(32.dp).background(Color(c), CircleShape)
                    .border(if (c == current) BorderStroke(3.dp, Color.White) else BorderStroke(1.dp, Color.Gray), CircleShape)
                    .clickable { onPick(c) })
            }
        }
        OutlinedTextField(hex, { v ->
            hex = v.filter { it.isLetterOrDigit() }.take(6).uppercase()
            if (hex.length == 6) hex.toLongOrNull(16)?.let { onPick(0xFF000000 or it) }
        }, label = { Text("হেক্স রঙ (যেমন FF8800)") }, singleLine = true, modifier = Modifier.padding(top = 6.dp).fillMaxWidth())
    }
}

@Composable
fun SettingsScreen(prefs: Prefs, onChange: () -> Unit, onPermissions: () -> Unit, onAllFiles: () -> Unit, onWidgets: () -> Unit, onClose: () -> Unit) {
    var tools by remember { mutableStateOf(prefs.tools) }
    var name by remember { mutableStateOf(prefs.userName) }
    var appBg by remember { mutableLongStateOf(prefs.appBg) }
    var barBg by remember { mutableLongStateOf(prefs.barBg) }
    var colorFor by remember { mutableStateOf<Tool?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    fun save(l: List<Tool>) { tools = l; prefs.tools = l; onChange() }

    Surface(Modifier.fillMaxSize(), color = Color(0xFF12172F)) {
        Column(Modifier.fillMaxSize().padding(16.dp).then(Modifier.verticalScrollCompat())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("সেটিংস", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClose) { Icon(Icons.Filled.Close, null, tint = Color.White) }
            }
            OutlinedTextField(name, { name = it; prefs.userName = it; onChange() }, label = { Text("আপনার নাম (ওমনি-ফাইন্ডারের পাশে দেখাবে)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Text("অ্যাপের ব্যাকগ্রাউন্ড", color = Color.White); Spacer(Modifier.height(6.dp))
            ColorPicker(appBg) { appBg = it; prefs.appBg = it; onChange() }
            Spacer(Modifier.height(12.dp))
            Text("সার্চ বার ও টুলবারের ব্যাকগ্রাউন্ড", color = Color.White); Spacer(Modifier.height(6.dp))
            ColorPicker(barBg) { barBg = it; prefs.barBg = it; onChange() }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onPermissions) { Text("পারমিশন দিন") }
                Button(onAllFiles) { Text("সব ফাইল অ্যাক্সেস") }
            }
            Spacer(Modifier.height(8.dp))
            Button(onWidgets) { Text("হোমস্ক্রিনে উইজেট বসান") }
            Spacer(Modifier.height(16.dp))
            Text("আমার টুলস (${tools.size}) — ← → দিয়ে সাজান, − দিয়ে বাদ দিন", color = Color.White, fontWeight = FontWeight.Bold)
            tools.forEachIndexed { i, t ->
                key(t, tick) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(Color(prefs.toolColor(t)), RoundedCornerShape(10.dp)).clickable { colorFor = if (colorFor == t) null else t }, contentAlignment = Alignment.Center) {
                            ToolGlyph(t.glyph, 22.dp) }
                        Text(t.label + " (রঙ বদলান)", color = Color.White, modifier = Modifier.weight(1f).padding(start = 10.dp).clickable { colorFor = if (colorFor == t) null else t })
                        IconButton({ if (i > 0) save(tools.toMutableList().also { it.add(i - 1, it.removeAt(i)) }) }) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
                        IconButton({ if (i < tools.lastIndex) save(tools.toMutableList().also { it.add(i + 1, it.removeAt(i)) }) }) { Icon(Icons.Filled.ArrowForward, null, tint = Color.White) }
                        IconButton({ save(tools - t) }) { Icon(Icons.Filled.RemoveCircle, null, tint = Color(0xFFFF6B6B)) }
                    }
                    if (colorFor == t) ColorPicker(prefs.toolColor(t)) { prefs.setToolColor(t, it); tick++; onChange() }
                }
            }
            Spacer(Modifier.height(12.dp))
            val rest = Tool.values().filter { it !in tools }
            if (rest.isNotEmpty()) {
                Text("যোগ করুন", color = Color.White, fontWeight = FontWeight.Bold)
                rest.forEach { t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(Color(prefs.toolColor(t)), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            ToolGlyph(t.glyph, 22.dp) }
                        Text(t.label, color = Color.White, modifier = Modifier.weight(1f).padding(start = 10.dp))
                        IconButton({ save(tools + t) }) { Icon(Icons.Filled.AddCircle, null, tint = Color(0xFF4ADE80)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier =
    this.then(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()))


/** অ্যাপের ভেতর থেকে হোমস্ক্রিনে উইজেট বসানোর স্ক্রিন। */
@Composable
fun WidgetsDialog(onClose: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    androidx.compose.ui.window.Dialog(onClose, androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF12172F)) {
            Column(Modifier.statusBarsPadding().padding(16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("হোমস্ক্রিন উইজেট", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClose) { Icon(Icons.Filled.Close, null, tint = Color.White) }
                }
                Text("উইজেট বসালে অ্যাপ না খুলেই হোমস্ক্রিন থেকে সার্চ করা যায়। রঙ ও টুলস আপনার সেটিংস অনুযায়ী বদলায়।", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
                WidgetKind.values().forEach { k ->
                    val n = remember(tick) { WidgetUpdater.count(ctx, k) }
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(18.dp)).padding(14.dp)) {
                        Text(k.title, color = Color(0xFFFFE066), fontWeight = FontWeight.Bold)
                        Text(k.desc, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                        Text(if (n > 0) "বসানো আছে: $n টি" else "এখনো বসানো হয়নি", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        Button({ WidgetUpdater.pin(ctx, k); tick++ }, Modifier.padding(top = 8.dp)) { Text("হোমস্ক্রিনে বসান") }
                    }
                }
                Text("টিপস: নিশ্চিত করার প্রশ্ন এলে \"যোগ করুন\" চাপুন। কিছু ফোনে সরাসরি বসানো কাজ না করলে হোমস্ক্রিনে ফাঁকা জায়গায় চেপে ধরে ▸ উইজেট ▸ ওমনি-ফাইন্ডার থেকে টেনে আনুন।", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}
