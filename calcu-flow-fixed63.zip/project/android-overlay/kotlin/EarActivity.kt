package com.earflow.app

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.SystemClock
import android.media.PlaybackParams
import android.media.audiofx.LoudnessEnhancer
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

class EarActivity : AppCompatActivity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var list: ListView
    private lateinit var stats: TextView
    private lateinit var tabCall: TextView
    private lateinit var tabVideo: TextView
    private var tab = 0
    private val sortNames = listOf("↕ নতুন আগে", "↕ পুরনো আগে", "↕ বড় ফাইল আগে", "↕ নাম অনুযায়ী")
    private var sortMode = 0
    private lateinit var sortPill: TextView
    private var voiceRec: MediaRecorder? = null
    private var query = ""
    private var all = listOf<File>()
    private var shown = listOf<File>()
    private var unlocked = false
    private var authing = false
    private var leftAt = 0L
    private val ui = Handler(Looper.getMainLooper())
    private val thumbs = LruCache<String, Bitmap>(60)
    private val durs = ConcurrentHashMap<String, Long>()
    private val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault())
    private val palette = intArrayOf(0xFF5B2EFF.toInt(), 0xFFE040FB.toInt(), 0xFFFF7A00.toInt(),
        0xFF00B894.toInt(), 0xFF0984E3.toInt(), 0xFFFF1744.toInt())

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            ContextCompat.startForegroundService(this, Intent(this, ScreenRecordService::class.java).apply {
                action = "START"; putExtra("code", r.resultCode); putExtra("data", r.data)
            })
            moveTaskToBack(true)
        }
    }

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        authing = false
        if (r.resultCode == RESULT_OK) {
            unlocked = true; leftAt = System.currentTimeMillis()
            root.visibility = View.VISIBLE; refresh()
        } else finish()
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun pill(t: String, color: Int, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(8), dp(12), dp(8), dp(12))
        background = bg(color, 14)
        setOnClickListener { f() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("ef", Context.MODE_PRIVATE)
        window.statusBarColor = 0xFF5B2EFF.toInt()
        autoDelete()

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF6F3FF.toInt()) }

        // ---- হেডার ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF5B2EFF.toInt(), 0xFFE040FB.toInt(), 0xFFFF7A00.toInt())).apply {
                val r = dp(24).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = "←"; textSize = 26f; setTextColor(Color.WHITE); setPadding(0, 0, dp(12), 0)
            setOnClickListener { finish() }
        })
        val logoRes = resources.getIdentifier("pad_ear", "drawable", packageName)
        if (logoRes != 0) titleRow.addView(ImageView(this).apply { setImageResource(logoRes) },
            LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
        titleRow.addView(TextView(this).apply {
            text = "ইয়ার-ফ্লো"; textSize = 28f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(titleRow)
        stats = TextView(this).apply { textSize = 13f; setTextColor(0xFFFFFFFF.toInt()); alpha = 0.9f; setPadding(0, dp(2), 0, dp(6)) }
        header.addView(stats)
        header.addView(Switch(this).apply {
            text = "অটো কল রেকর্ড"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("auto", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("auto", on).apply()
                ContextCompat.startForegroundService(this@EarActivity,
                    Intent(this@EarActivity, CallRecordService::class.java).setAction(if (on) "IDLE" else "QUIT"))
            }
        })
        root.addView(header)

        // ---- অ্যাকশন বাটন ----
        fun lp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) }
        val actions = LinearLayout(this).apply { setPadding(dp(10), dp(14), dp(10), 0) }
        actions.addView(pill("🔴 স্ক্রিন রেকর্ড", 0xFFFF1744.toInt()) { startScreen() }, lp())
        actions.addView(pill("⚙ সেটিংস", 0xFF5B2EFF.toInt()) { settingsDialog() }, lp())
        actions.addView(pill("✔ সেটআপ", 0xFF00B894.toInt()) { setupDialog() }, lp())
        root.addView(actions)
        val actions2 = LinearLayout(this).apply { setPadding(dp(10), dp(8), dp(10), 0) }
        actions2.addView(pill("🎙 ভয়েস রেকর্ড", 0xFFE040FB.toInt()) { voiceDialog() }, lp())
        sortPill = pill(sortNames[0], 0xFF0984E3.toInt()) {
            sortMode = (sortMode + 1) % sortNames.size; sortPill.text = sortNames[sortMode]; refresh()
        }
        actions2.addView(sortPill, lp())
        root.addView(actions2)

        // ---- ট্যাব ----
        val tabs = LinearLayout(this).apply { setPadding(dp(10), dp(10), dp(10), 0) }
        tabCall = pill("🎧 অডিও রেকর্ডিং", 0) { tab = 0; styleTabs(); refresh() }
        tabVideo = pill("🎬 স্ক্রিন ভিডিও", 0) { tab = 1; styleTabs(); refresh() }
        tabs.addView(tabCall, lp()); tabs.addView(tabVideo, lp())
        root.addView(tabs)
        styleTabs()

        // ---- সার্চ ----
        val search = EditText(this).apply {
            hint = "🔍 নাম বা নম্বর খুঁজুন"; setSingleLine(); textSize = 14f
            background = bg(Color.WHITE, 14); setPadding(dp(14), dp(10), dp(14), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { query = e?.toString()?.trim()?.lowercase() ?: ""; applyFilter() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(14), dp(10), dp(14), 0) })

        // ---- লিস্ট ----
        val frame = FrameLayout(this)
        list = ListView(this).apply {
            divider = null; dividerHeight = dp(8)
            setPadding(dp(14), dp(10), dp(14), dp(10)); clipToPadding = false
            adapter = FileAdapter()
        }
        val empty = TextView(this).apply { text = "এখনো কিছু নেই\n🎙 ভয়েস রেকর্ড বা 🔴 স্ক্রিন রেকর্ড চেপে শুরু করুন"; gravity = Gravity.CENTER; textSize = 16f; setTextColor(0xFF888888.toInt()) }
        frame.addView(list); frame.addView(empty)
        list.emptyView = empty
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (prefs.getBoolean("auto", false))
            ContextCompat.startForegroundService(this, Intent(this, CallRecordService::class.java).setAction("IDLE"))

        list.setOnItemClickListener { _, _, pos, _ ->
            val f = shown[pos]
            if (tab == 1) startActivity(Intent(this, EditorActivity::class.java).putExtra("path", f.absolutePath))
            else playDialog(f)
        }
        list.setOnItemLongClickListener { _, _, pos, _ -> optionsDialog(shown[pos]); true }
    }

    override fun onResume() { super.onResume(); checkLock(); refresh() }
    override fun onStop() { super.onStop(); leftAt = System.currentTimeMillis() }

    // ---------------- অ্যাপ লক ----------------
    private fun checkLock() {
        if (!prefs.getBoolean("lock", false)) { root.visibility = View.VISIBLE; return }
        if (unlocked && System.currentTimeMillis() - leftAt < 30_000) { root.visibility = View.VISIBLE; return }
        unlocked = false
        root.visibility = View.INVISIBLE
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val i = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("ইয়ার-ফ্লো", "আনলক করুন") else null
        if (i == null) { unlocked = true; root.visibility = View.VISIBLE; return }
        if (!authing) { authing = true; authLauncher.launch(i) }
    }

    private fun autoDelete() {
        val days = prefs.getInt("autodel", 0)
        if (days <= 0) return
        val cut = System.currentTimeMillis() - days * 86_400_000L
        File(getExternalFilesDir(null), "calls").listFiles()?.filter { it.lastModified() < cut && !isFav(it) }?.forEach { Util.deleteShared(this, it); it.delete() }
    }

    private fun styleTabs() {
        for ((i, t) in listOf(tabCall, tabVideo).withIndex()) {
            val sel = i == tab
            t.background = bg(if (sel) 0xFF5B2EFF.toInt() else 0xFFE4DDFB.toInt(), 14)
            t.setTextColor(if (sel) Color.WHITE else 0xFF5B2EFF.toInt())
        }
    }

    // ---------------- লিস্ট ----------------
    private fun refresh() {
        Thread { Util.syncAll(applicationContext) }.start()
        val base = getExternalFilesDir(null)
        val calls = File(base, "calls").listFiles()?.filter { it.isFile } ?: emptyList()
        val vids = File(base, "videos").listFiles()?.filter { it.isFile } ?: emptyList()
        val total = (calls + vids).sumOf { it.length() }
        stats.text = "🎧 ${calls.size} অডিও   🎬 ${vids.size} ভিডিও   💾 ${Util.size(total)}"
        all = sorted(if (tab == 0) calls else vids)
        applyFilter()
    }

    private fun sorted(l: List<File>): List<File> {
        val cmp: Comparator<File> = when (sortMode) {
            1 -> compareBy<File> { it.lastModified() }
            2 -> compareByDescending<File> { it.length() }
            3 -> compareBy<File> { it.name.lowercase() }
            else -> compareByDescending<File> { it.lastModified() }
        }
        return l.sortedWith(compareByDescending<File> { isFav(it) }.then(cmp))
    }

    private fun applyFilter() {
        shown = if (query.isEmpty()) all
        else all.filter { it.nameWithoutExtension.replace("_", " ").lowercase().contains(query) }
        (list.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    private inner class Holder(val card: LinearLayout, val avatar: TextView, val thumb: ImageView,
                               val title: TextView, val sub: TextView, val dur: TextView) {
        var key = ""
    }

    private inner class FileAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h: Holder
            val v: View
            if (convertView == null) {
                val ctx = this@EarActivity
                val card = LinearLayout(ctx).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(12), dp(12), dp(12)); background = bg(Color.WHITE, 16)
                }
                val frame = FrameLayout(ctx)
                val avatar = TextView(ctx).apply {
                    gravity = Gravity.CENTER; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                }
                val thumb = ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE
                    background = bg(0xFFDDDDDD.toInt(), 12); clipToOutline = true
                }
                frame.addView(avatar, FrameLayout.LayoutParams(dp(54), dp(54)))
                frame.addView(thumb, FrameLayout.LayoutParams(dp(54), dp(54)))
                card.addView(frame)
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
                val title = TextView(ctx).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF222222.toInt()); setSingleLine() }
                val sub = TextView(ctx).apply { textSize = 12f; setTextColor(0xFF777777.toInt()); setSingleLine() }
                col.addView(title); col.addView(sub)
                card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val dur = TextView(ctx).apply { textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF5B2EFF.toInt()) }
                card.addView(dur)
                h = Holder(card, avatar, thumb, title, sub, dur)
                card.tag = h
                v = card
            } else { v = convertView; h = convertView.tag as Holder }
            bind(h, shown[position])
            return v
        }
    }

    private fun bind(h: Holder, f: File) {
        val meta = fmt.format(Date(f.lastModified())) + " • " + Util.size(f.length())
        if (tab == 0) {
            val ci = Util.parseCall(f)
            val voice = f.name.startsWith("Voice_")
            val name = ci?.name ?: (if (voice) "ভয়েস রেকর্ড" else f.nameWithoutExtension)
            h.title.text = (if (isFav(f)) "⭐ " else "") + name
            h.sub.text = (if (ci != null) (if (ci.incoming) "↙ আসা • " else "↗ করা • ") + ci.number + " • " else "") + meta
            h.avatar.visibility = View.VISIBLE; h.thumb.visibility = View.GONE
            h.avatar.text = if (voice) "🎙" else (name.firstOrNull()?.uppercase() ?: "?")
            h.avatar.background = bg(palette[abs(name.hashCode()) % palette.size], 16)
        } else {
            h.title.text = f.nameWithoutExtension.removePrefix("EarFlow_").replace("_", " ")
            h.sub.text = meta
            h.avatar.visibility = View.GONE; h.thumb.visibility = View.VISIBLE
        }
        val key = f.absolutePath
        h.key = key
        val d0 = durs[key]
        h.dur.text = if (d0 != null) Util.dur(d0) else ""
        h.thumb.setImageBitmap(thumbs.get(key))
        if (d0 == null || (tab == 1 && thumbs.get(key) == null)) {
            Thread {
                val d = Util.durationOf(f)
                durs[key] = d
                val b = if (f.extension == "mp4") Util.thumb(f) else null
                if (b != null) thumbs.put(key, b)
                runOnUiThread {
                    if (h.key == key) { h.dur.text = Util.dur(d); if (b != null) h.thumb.setImageBitmap(b) }
                }
            }.start()
        }
    }

    // ---------------- অপশন / প্লেয়ার ----------------
    private fun isFav(f: File) = (prefs.getStringSet("favs", emptySet()) ?: emptySet()).contains(f.name)

    private fun toggleFav(f: File) {
        val set = HashSet<String>(prefs.getStringSet("favs", emptySet()) ?: emptySet())
        if (!set.remove(f.name)) set.add(f.name)
        prefs.edit().putStringSet("favs", set).apply()
    }

    private fun optionsDialog(f: File) {
        val video = f.extension == "mp4"
        val items = arrayOf(
            if (isFav(f)) "☆ ফেভারিট থেকে সরান" else "⭐ ফেভারিট করুন",
            "📤 শেয়ার",
            if (video) "🎞 গ্যালারিতে সেভ" else "🎵 মিউজিক ফোল্ডারে সেভ",
            "✏ নাম বদলান",
            "🗑 মুছুন")
        AlertDialog.Builder(this).setTitle(f.nameWithoutExtension.replace("_", " ")).setItems(items) { _, i ->
            when (i) {
                0 -> { toggleFav(f); refresh() }
                1 -> Util.share(this, f)
                2 -> Toast.makeText(this, if (Util.export(this, f)) "সেভ হয়েছে" else "সেভ ব্যর্থ", Toast.LENGTH_SHORT).show()
                3 -> renameDialog(f)
                4 -> AlertDialog.Builder(this).setMessage("মুছে ফেলবেন?")
                    .setPositiveButton("হ্যাঁ") { _, _ -> Util.deleteShared(this, f); f.delete(); refresh() }
                    .setNegativeButton("না", null).show()
            }
        }.show()
    }

    private fun renameDialog(f: File) {
        val et = EditText(this).apply { setText(f.nameWithoutExtension); setSingleLine(); setSelectAllOnFocus(true) }
        val holder = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et) }
        AlertDialog.Builder(this).setTitle("নাম বদলান").setView(holder)
            .setPositiveButton("সেভ") { _, _ ->
                val nn = et.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (nn.isEmpty()) return@setPositiveButton
                val dst = File(f.parentFile, nn + "." + f.extension)
                if (dst.exists()) { Toast.makeText(this, "এই নামে ফাইল আগে থেকেই আছে", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val wasFav = isFav(f)
                Util.deleteShared(this, f)
                if (f.renameTo(dst)) {
                    if (wasFav) { toggleFav(f); toggleFav(dst) }
                    Toast.makeText(this, "নাম বদলানো হয়েছে", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "নাম বদলানো যায়নি", Toast.LENGTH_SHORT).show()
                Thread { Util.syncAll(applicationContext) }.start()
                refresh()
            }.setNegativeButton("বাদ", null).show()
    }

    // ---------------- ভয়েস রেকর্ডার (মাইক্রোফোন) ----------------
    private fun mmss(ms: Long): String { val t = ms / 1000; return "%02d:%02d".format(t / 60, t % 60) }

    private fun voiceDialog() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
            Toast.makeText(this, "মাইক্রোফোনের অনুমতি দিয়ে আবার চাপুন", Toast.LENGTH_LONG).show(); return
        }
        val dir = File(getExternalFilesDir(null), "calls").apply { mkdirs() }
        val out = File(dir, "Voice_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a")
        val rec = try {
            MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000); setAudioSamplingRate(44100)
                setOutputFile(out.absolutePath); prepare(); start()
            }
        } catch (e: Exception) {
            out.delete(); Toast.makeText(this, "রেকর্ড শুরু করা যায়নি (মাইক্রোফোন অন্য কাজে ব্যস্ত?)", Toast.LENGTH_LONG).show(); return
        }
        voiceRec = rec
        var acc = 0L
        var seg = SystemClock.elapsedRealtime()
        var paused = false
        val timer = TextView(this).apply {
            text = "00:00"; textSize = 44f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(0xFFFF1744.toInt()); setPadding(0, dp(18), 0, dp(6))
        }
        val state = TextView(this).apply { text = "🔴 রেকর্ড হচ্ছে… (অ্যাপ খোলা রাখুন)"; gravity = Gravity.CENTER; textSize = 13f }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(timer); addView(state); setPadding(dp(20), dp(8), dp(20), dp(4)) }
        val tick = object : Runnable {
            override fun run() {
                timer.text = mmss(acc + if (paused) 0L else SystemClock.elapsedRealtime() - seg)
                ui.postDelayed(this, 300)
            }
        }
        val d = AlertDialog.Builder(this).setTitle("🎙 ভয়েস রেকর্ডার").setView(box).setCancelable(false)
            .setPositiveButton("⏹ সেভ", null).setNeutralButton("⏸ বিরতি", null).setNegativeButton("✕ বাতিল", null).create()
        d.setOnDismissListener { ui.removeCallbacks(tick) }
        d.show()
        ui.post(tick)
        fun finishRec(save: Boolean) {
            ui.removeCallbacks(tick)
            try { rec.stop() } catch (e: Exception) { if (out.length() < 1000) out.delete() }
            try { rec.release() } catch (e: Exception) {}
            voiceRec = null
            if (!save) out.delete()
            else if (out.exists()) {
                Toast.makeText(this, "✅ সেভ হয়েছে — ফোনের স্টোরেজেও যাবে", Toast.LENGTH_LONG).show()
                Thread { try { Thread.sleep(6000) } catch (e: Exception) {}; Util.syncAll(applicationContext) }.start()
            }
            d.dismiss(); refresh()
        }
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { finishRec(true) }
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { finishRec(false) }
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            try {
                if (!paused) { rec.pause(); acc += SystemClock.elapsedRealtime() - seg; paused = true
                    d.getButton(AlertDialog.BUTTON_NEUTRAL).text = "▶ চালু"; state.text = "⏸ বিরতিতে আছে" }
                else { rec.resume(); seg = SystemClock.elapsedRealtime(); paused = false
                    d.getButton(AlertDialog.BUTTON_NEUTRAL).text = "⏸ বিরতি"; state.text = "🔴 রেকর্ড হচ্ছে… (অ্যাপ খোলা রাখুন)" }
            } catch (e: Exception) { Toast.makeText(this, "এই ফোনে বিরতি সমর্থিত নয়", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun playDialog(f: File) {
        val mp = MediaPlayer()
        try { mp.setDataSource(f.absolutePath); mp.prepare() } catch (e: Exception) {
            mp.release(); Toast.makeText(this, "ফাইল চালানো যাচ্ছে না", Toast.LENGTH_SHORT).show(); return
        }
        // প্লেব্যাকে আস্তে আওয়াজ জোরে করার জন্য
        val enh: LoudnessEnhancer? = try { LoudnessEnhancer(mp.audioSessionId).apply { enabled = true } } catch (e: Exception) { null }
        var speed = 1f
        var boost = 0
        val ci = Util.parseCall(f)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(8)) }
        box.addView(TextView(this).apply { text = ci?.name ?: f.nameWithoutExtension; textSize = 18f; typeface = Typeface.DEFAULT_BOLD })
        if (ci != null) box.addView(TextView(this).apply { text = ci.number + " • " + (if (ci.incoming) "আসা কল" else "করা কল") })
        val bar = SeekBar(this).apply { max = mp.duration }
        val time = TextView(this).apply { gravity = Gravity.CENTER }
        box.addView(bar); box.addView(time)

        fun applySpeed() { if (mp.isPlaying) mp.playbackParams = PlaybackParams().setSpeed(speed) }
        fun mkRow(vararg v: TextView): LinearLayout {
            val r = LinearLayout(this).apply { setPadding(0, dp(8), 0, 0) }
            for (b in v) r.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
            return r
        }

        val playBtn = pill("⏸ থামান", 0xFF5B2EFF.toInt()) {}
        playBtn.setOnClickListener {
            if (mp.isPlaying) { mp.pause(); playBtn.text = "▶ প্লে" }
            else { mp.start(); applySpeed(); playBtn.text = "⏸ থামান" }
        }
        val speedBtn = pill("1.0x", 0xFFFF7A00.toInt()) {}
        speedBtn.setOnClickListener {
            speed = if (speed == 1f) 1.5f else if (speed == 1.5f) 2f else 1f
            speedBtn.text = String.format(Locale.US, "%.1fx", speed)
            applySpeed()
        }
        val shareBtn = pill("📤", 0xFF0984E3.toInt()) { Util.share(this, f) }
        val boostBtn = pill("🔊 বুস্ট: বন্ধ", 0xFF00B894.toInt()) {}
        boostBtn.setOnClickListener {
            boost = (boost + 1) % 4
            val db = intArrayOf(0, 600, 1200, 1800)[boost]
            try { enh?.setTargetGain(db) } catch (_: Exception) {}
            boostBtn.text = if (boost == 0) "🔊 বুস্ট: বন্ধ" else "🔊 +" + (db / 100) + "dB"
        }
        val backBtn = pill("⏪ ১০s", 0xFF636E72.toInt()) { mp.seekTo((mp.currentPosition - 10000).coerceAtLeast(0)) }
        val fwdBtn = pill("১০s ⏩", 0xFF636E72.toInt()) { mp.seekTo((mp.currentPosition + 10000).coerceAtMost(mp.duration)) }
        box.addView(mkRow(playBtn, speedBtn, shareBtn))
        box.addView(mkRow(backBtn, boostBtn, fwdBtn))

        val tick = object : Runnable {
            override fun run() {
                bar.progress = mp.currentPosition
                time.text = Util.dur(mp.currentPosition.toLong()) + " / " + Util.dur(mp.duration.toLong())
                ui.postDelayed(this, 250)
            }
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { if (user) mp.seekTo(p) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        mp.setOnCompletionListener { playBtn.text = "▶ প্লে" }
        AlertDialog.Builder(this).setView(box)
            .setOnDismissListener {
                ui.removeCallbacks(tick)
                try { enh?.release() } catch (_: Exception) {}
                mp.release()
            }
            .setPositiveButton("বন্ধ", null).show()
        mp.start(); tick.run()
    }

    // ---------------- স্ক্রিন রেকর্ড ----------------
    private fun startScreen() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে ওভারলে পারমিশন দিন", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 2)
        projLauncher.launch((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
    }

    // ---------------- সেটআপ (✅/❌ স্ট্যাটাস সহ) ----------------
    private fun setupDialog() {
        val rt = listOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
            .all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        val ov = Settings.canDrawOverlays(this)
        val bat = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        fun m(ok: Boolean) = if (ok) "✅ " else "❌ "
        val items = arrayOf(
            m(rt) + "১. পারমিশন (ফোন, কল লগ, মাইক, কন্টাক্ট)",
            m(ov) + "২. ওভারলে (ভাসমান বিন্দু)",
            m(bat) + "৩. ব্যাটারি অপটিমাইজেশন বন্ধ",
            m(acc) + "৪. অ্যাক্সেসিবিলিটি চালু (কলে মাইকের জন্য)")
        AlertDialog.Builder(this).setTitle("সেটআপ ধাপ").setItems(items) { _, i ->
            when (i) {
                0 -> ActivityCompat.requestPermissions(this, arrayOf(
                    Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.PROCESS_OUTGOING_CALLS, Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS), 1)
                1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                2 -> if (!bat) startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                3 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }.show()
    }

    // ---------------- সেটিংস ----------------
    private fun settingsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        fun head(t: String) = box.addView(TextView(this).apply {
            text = t; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF5B2EFF.toInt()); setPadding(0, dp(12), 0, dp(2))
        })
        fun spin(label: String, names: List<String>, vals: List<Int>, key: String, def: Int) {
            box.addView(TextView(this).apply { text = label })
            box.addView(Spinner(this).apply {
                adapter = ArrayAdapter(this@EarActivity, android.R.layout.simple_spinner_dropdown_item, names)
                setSelection(vals.indexOf(prefs.getInt(key, def)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        prefs.edit().putInt(key, vals[pos]).apply()
                    }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            })
        }
        fun chk(label: String, key: String, def: Boolean) = box.addView(CheckBox(this).apply {
            text = label; isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean(key, on).apply()
                if (key == "lock" && on && !(getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure)
                    Toast.makeText(this@EarActivity, "আগে ফোনে স্ক্রিন লক (PIN/প্যাটার্ন) সেট করুন", Toast.LENGTH_LONG).show()
            }
        })

        head("🎬 স্ক্রিন রেকর্ড")
        spin("রেজোলিউশন", listOf("720p", "1080p", "ফোনের নেটিভ"), listOf(720, 1080, 0), "quality", 1080)
        spin("FPS", listOf("30", "60"), listOf(30, 60), "fps", 60)
        spin("বিটরেট", listOf("8 Mbps", "16 Mbps", "24 Mbps"), listOf(8, 16, 24), "bitrate", 16)
        chk("মাইক্রোফোন (ভয়েস) রেকর্ড", "mic", true)
        chk("৩-২-১ কাউন্টডাউন", "countdown", true)
        head("👆 ইশারা-বিন্দু")
        chk("ভাসমান বিন্দু দেখান", "dot", true)
        spin("রঙ", listOf("লাল", "হলুদ", "সবুজ"), listOf(0, 1, 2), "dotColor", 0)
        spin("সাইজ", listOf("ছোট", "মাঝারি", "বড়"), listOf(64, 96, 140), "dotSize", 96)
        head("📞 কল রেকর্ড")
        spin("কোন কল রেকর্ড হবে", listOf("সব কল", "শুধু অজানা নম্বর", "শুধু সেভ করা কন্টাক্ট"), listOf(0, 1, 2), "recmode", 0)
        chk("কলে অটো স্পিকার + ফুল ভলিউম", "speaker", true)
        spin("অটো সাউন্ড বুস্ট (সর্বোচ্চ)", listOf("৪x", "৮x", "১২x", "২০x", "৩০x"), listOf(4, 8, 12, 20, 30), "gain", 20)
        spin("অডিও কোয়ালিটি", listOf("সাধারণ (32 kbps)", "ভালো (48 kbps)", "সেরা (64 kbps)"), listOf(32, 48, 64), "callkbps", 48)
        chk("সিস্টেম নয়েজ সাপ্রেশন (আস্তে কথা কেটে যেতে পারে)", "ns", false)
        chk("৩ সেকেন্ডের কম রেকর্ডিং বাদ দিন", "skipshort", true)
        spin("পুরনো কল রেকর্ডিং অটো ডিলিট", listOf("বন্ধ", "৭ দিন", "৩০ দিন", "৯০ দিন"), listOf(0, 7, 30, 90), "autodel", 0)
        head("🔒 প্রাইভেসি")
        chk("অ্যাপ লক (ফোনের PIN/ফিঙ্গারপ্রিন্ট)", "lock", false)

        AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("ঠিক আছে", null).show()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        voiceRec?.let { try { it.stop() } catch (e: Exception) {}; try { it.release() } catch (e: Exception) {} }
        voiceRec = null
        super.onDestroy()
    }
}
