package com.omnifinder.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import __APP_ID__.R

/** তিনটি হোমস্ক্রিন উইজেটের ভিউ তৈরি — রঙ ও টুলস সেটিংস থেকে আসে। */
object WidgetViews {
    private fun pi(ctx: Context, code: Int, tool: Tool?, focus: Boolean = false) = PendingIntent.getActivity(
        ctx, code,
        Intent(ctx, OmniActivity::class.java).putExtra("tool", tool?.name).putExtra("focus", focus)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun tint(v: RemoteViews, id: Int, color: Long) = v.setInt(id, "setColorFilter", color.toInt())

    /** ৩ডি-ধাঁচের রঙিন টাইল বিটম্যাপ (গ্রেডিয়েন্ট + হাইলাইট + নিজস্ব আইকন)। */
    private fun tile(t: Tool, color: Long, px: Int = 132): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888); val c = Canvas(bmp)
        val base = color.toInt(); val r = px * 0.3f; val rect = RectF(4f, 4f, px - 4f, px - 4f)
        fun mix(a: Int, b: Int, f: Float) = Color.rgb(
            (Color.red(a) * (1 - f) + Color.red(b) * f).toInt(), (Color.green(a) * (1 - f) + Color.green(b) * f).toInt(), (Color.blue(a) * (1 - f) + Color.blue(b) * f).toInt())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, px.toFloat(), intArrayOf(mix(base, Color.WHITE, .35f), base, mix(base, Color.BLACK, .35f)), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        p.shader = LinearGradient(0f, 6f, 0f, px * .4f, 0x73FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(px * .12f, 8f, px * .88f, px * .38f), r * .7f, r * .7f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x55FFFFFF; c.drawRoundRect(rect, r, r, p)
        val g = px * 0.56f
        ToolIcons.draw(c, t.glyph, (px - g) / 2f, (px - g) / 2f, g, Color.WHITE)
        return bmp
    }

    private fun fillTools(ctx: Context, v: RemoteViews, p: Prefs, tools: List<Tool>, imgIds: IntArray, labelIds: IntArray?, codeBase: Int) {
        imgIds.forEachIndexed { i, id ->
            val t = tools.getOrNull(i)
            if (t == null) { v.setViewVisibility(id, View.INVISIBLE); labelIds?.let { v.setViewVisibility(it[i], View.INVISIBLE) }; return@forEachIndexed }
            v.setViewVisibility(id, View.VISIBLE)
            v.setImageViewBitmap(id, tile(t, p.toolColor(t)))
            v.setOnClickPendingIntent(id, pi(ctx, codeBase + i, t))
            labelIds?.let { v.setViewVisibility(it[i], View.VISIBLE); v.setTextViewText(it[i], t.label); v.setOnClickPendingIntent(it[i], pi(ctx, codeBase + i, t)) }
        }
    }

    fun search(ctx: Context): RemoteViews {
        val p = Prefs(ctx); val v = RemoteViews(ctx.packageName, R.layout.of_widget_search)
        tint(v, R.id.w_bg, p.appBg); tint(v, R.id.w_pillbg, p.barBg)
        v.setOnClickPendingIntent(R.id.w_bar, pi(ctx, 1, null, focus = true))
        fillTools(ctx, v, p, p.tools.take(5), intArrayOf(R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4), null, 10)
        return v
    }

    fun bar(ctx: Context): RemoteViews {
        val p = Prefs(ctx); val v = RemoteViews(ctx.packageName, R.layout.of_widget_bar)
        tint(v, R.id.w_bg, p.barBg)
        v.setOnClickPendingIntent(R.id.w_bar, pi(ctx, 2, null, focus = true))
        v.setOnClickPendingIntent(R.id.w_mic, pi(ctx, 3, Tool.VOICE))
        return v
    }

    fun tools(ctx: Context): RemoteViews {
        val p = Prefs(ctx); val v = RemoteViews(ctx.packageName, R.layout.of_widget_tools)
        tint(v, R.id.w_bg, p.appBg)
        fillTools(ctx, v, p, p.tools.take(8),
            intArrayOf(R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5, R.id.w_t6, R.id.w_t7),
            intArrayOf(R.id.w_l0, R.id.w_l1, R.id.w_l2, R.id.w_l3, R.id.w_l4, R.id.w_l5, R.id.w_l6, R.id.w_l7), 30)
        return v
    }
}

enum class WidgetKind(val title: String, val desc: String, val cls: Class<*>, val build: (Context) -> RemoteViews) {
    SEARCH("সার্চ + কুইক টুলস (৪×২)", "সার্চ বার ও আপনার প্রথম ৫টি টুল", SearchWidget::class.java, WidgetViews::search),
    BAR("স্লিম সার্চ বার (৪×১)", "ছোট সার্চ বার, পাশে ভয়েস বাটন", BarWidget::class.java, WidgetViews::bar),
    TOOLS("টুলস গ্রিড (৪×২)", "আপনার প্রথম ৮টি টুল নাম সহ", ToolsWidget::class.java, WidgetViews::tools);
}

object WidgetUpdater {
    /** সেটিংস (রঙ/টুল) বদলালে বসানো সব উইজেট নতুন করে আঁকে। */
    fun updateAll(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        WidgetKind.values().forEach { k ->
            val ids = m.getAppWidgetIds(ComponentName(ctx, k.cls))
            if (ids.isNotEmpty()) runCatching { m.updateAppWidget(ids, k.build(ctx)) }
        }
    }

    fun count(ctx: Context, k: WidgetKind) = AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, k.cls)).size

    /** অ্যাপের ভেতর থেকেই হোমস্ক্রিনে বসানোর অনুরোধ (সিস্টেম নিশ্চিতকরণ চাইবে)। */
    fun pin(ctx: Context, k: WidgetKind) {
        val m = AppWidgetManager.getInstance(ctx)
        val ok = runCatching { m.isRequestPinAppWidgetSupported && m.requestPinAppWidget(ComponentName(ctx, k.cls), null, null) }.getOrDefault(false)
        if (!ok) Toast.makeText(ctx, "আপনার লঞ্চার সরাসরি বসানো সাপোর্ট করে না। হোমস্ক্রিনে ফাঁকা জায়গায় চেপে ধরুন ▸ উইজেট ▸ ওমনি-ফাইন্ডার", Toast.LENGTH_LONG).show()
    }
}
